ok 1 - setup test repository
ok 2 - clone an SVN repository with ignored www directory
ok 3 - init+fetch an SVN repository with ignored www directory
ok 4 - verify ignore-paths config saved by clone
ok 5 - SVN-side change outside of www
ok 6 - update git svn-cloned repo (config ignore)
ok 7 - update git svn-cloned repo (option ignore)
ok 8 - SVN-side change inside of ignored www
ok 9 - update git svn-cloned repo (config ignore)
ok 10 - update git svn-cloned repo (option ignore)
ok 11 - SVN-side change in and out of ignored www
ok 12 - update git svn-cloned repo again (config ignore)
ok 13 - update git svn-cloned repo again (option ignore)
# passed all 13 test(s)
1..13
