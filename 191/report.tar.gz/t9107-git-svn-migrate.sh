ok 1 - setup old-looking metadata
ok 2 - git-svn-HEAD is a real HEAD
ok 3 - initialize old-style (v0) git svn layout
ok 4 - initialize a multi-repository repo
ok 5 - multi-fetch works on partial urls + paths
ok 6 - migrate --minimize on old inited layout
ok 7 - .rev_db auto-converted to .rev_map.UUID
# passed all 7 test(s)
1..7
