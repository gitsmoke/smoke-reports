ok 1 - setup svnrepo
ok 2 - start import with incomplete authors file
ok 3 - imported 2 revisions successfully
ok 4 - continues to import once authors have been added
ok 5 - authors-file against globs
ok 6 - fetch fails on ee
ok 7 - failure happened without negative side effects
ok 8 - fetch continues after authors-file is fixed
ok 9 - fresh clone with svn.authors-file in config
# passed all 9 test(s)
1..9
