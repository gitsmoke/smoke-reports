ok 1 - setup
ok 2 - change submodule
ok 3 - change submodule url
ok 4 - "git submodule sync" should update submodule URLs
ok 5 - "git submodule sync" should update submodule URLs if not yet cloned
# passed all 5 test(s)
1..5
