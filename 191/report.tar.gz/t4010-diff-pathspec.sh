ok 1 - setup
ok 2 - limit to path should show nothing
ok 3 - limit to path1 should show path1/file1
ok 4 - limit to path1/ should show path1/file1
ok 5 - limit to file0 should show file0
ok 6 - diff-index with wildcard
ok 7 - limit to file0/ should emit nothing.
ok 8 - diff-tree pathspec
ok 9 - diff-tree with wildcard shows dir also matches
ok 10 - diff-tree -r with wildcard
# passed all 10 test(s)
1..10
