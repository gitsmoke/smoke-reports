ok 1 - prepare reference tree
ok 2 - prepare work tree
ok 3 - setup diff output
ok 4 - validate diff output
# passed all 4 test(s)
1..4
