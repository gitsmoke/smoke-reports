ok 1 - setup
ok 2 - rebase --onto master...topic
ok 3 - rebase --onto master...
ok 4 - rebase --onto master...side
ok 5 - rebase -i --onto master...topic
ok 6 - rebase -i --onto master...
ok 7 - rebase -i --onto master...side
# passed all 7 test(s)
1..7
