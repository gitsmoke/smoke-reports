ok 1 - setup
ok 2 - read-tree --prefix
# passed all 2 test(s)
1..2
