ok 1 - setup
ok 2 - Check merging after setting text=auto
ok 3 - Check merging addition of text=auto
ok 4 - Test delete/normalize conflict
# passed all 4 test(s)
1..4
