ok 1 - setup
ok 2 - merge-msg test #1
ok 3 - merge-msg test #2
ok 4 - merge-msg test #3-1
ok 5 - merge-msg test #3-2
ok 6 - merge-msg test #4-1
ok 7 - merge-msg test #4-2
ok 8 - merge-msg test #5-1
ok 9 - merge-msg test #5-2
ok 10 - merge-msg -F
ok 11 - merge-msg -F in subdirectory
ok 12 - merge-msg with nothing to merge
ok 13 - merge-msg tag
ok 14 - merge-msg two tags
ok 15 - merge-msg tag and branch
ok 16 - merge-msg lots of commits
# passed all 16 test(s)
1..16
