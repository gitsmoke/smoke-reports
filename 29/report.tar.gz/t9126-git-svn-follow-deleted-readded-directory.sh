# passed all 0 test(s)
1..0 # SKIP skipping svnserve test. (set $SVNSERVE_PORT to enable)
