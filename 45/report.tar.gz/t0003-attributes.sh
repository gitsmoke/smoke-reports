ok 1 - setup
ok 2 - attribute test
ok 3 - attribute test: read paths from stdin
ok 4 - root subdir attribute test
ok 5 - setup bare
ok 6 - bare repository: check that .gitattribute is ignored
ok 7 - bare repository: test info/attributes
# passed all 7 test(s)
1..7
