ok 1 - setup cvsroot environment
ok 2 - setup cvsroot
ok 3 - setup a cvs module
ok 4 - import a trivial module
ok 5 - pack refs
ok 6 - initial import has correct .git/cvs-revisions
ok 7 - update cvs module
ok 8 - update git module
ok 9 - update has correct .git/cvs-revisions
ok 10 - update cvs module
ok 11 - cvsimport.module config works
ok 12 - second update has correct .git/cvs-revisions
ok 13 - import from a CVS working tree
ok 14 - no .git/cvs-revisions created by default
ok 15 - test entire HEAD
# passed all 15 test(s)
1..15
