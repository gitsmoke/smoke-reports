ok 1 - setup
ok 2 - message for merging local branch
ok 3 - message for merging external branch
ok 4 - [merge] summary/log configuration
ok 5 - fmt-merge-msg -m
ok 6 - setup: expected shortlog for two branches
ok 7 - shortlog for two branches
ok 8 - merge-msg -F
ok 9 - merge-msg -F in subdirectory
ok 10 - merge-msg with nothing to merge
ok 11 - merge-msg tag
ok 12 - merge-msg two tags
ok 13 - merge-msg tag and branch
ok 14 - merge-msg lots of commits
# passed all 14 test(s)
1..14
