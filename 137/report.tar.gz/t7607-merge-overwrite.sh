ok 1 - setup
ok 2 - will not overwrite untracked file
ok 3 - will not overwrite new file
ok 4 - will not overwrite staged changes
ok 5 - will not overwrite removed file
ok 6 - will not overwrite re-added file
ok 7 - will not overwrite removed file with staged changes
ok 8 - set up unborn branch and content
not ok 9 - will not clobber WT/index when merging into unborn # TODO known breakage
# still have 1 known breakage(s)
# passed all remaining 8 test(s)
1..9
