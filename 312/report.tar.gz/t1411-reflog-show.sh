ok 1 - setup
ok 2 - log -g shows reflog headers
ok 3 - oneline reflog format
ok 4 - using @{now} syntax shows reflog date (multiline)
ok 5 - using @{now} syntax shows reflog date (oneline)
ok 6 - using --date= shows reflog date (multiline)
ok 7 - using --date= shows reflog date (oneline)
ok 8 - empty reflog file
# passed all 8 test(s)
1..8
