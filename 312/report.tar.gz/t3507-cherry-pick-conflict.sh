ok 1 - setup
ok 2 - failed cherry-pick does not advance HEAD
ok 3 - advice from failed cherry-pick
ok 4 - failed cherry-pick produces dirty index
ok 5 - failed cherry-pick registers participants in index
ok 6 - failed cherry-pick describes conflict in work tree
ok 7 - diff3 -m style
ok 8 - revert also handles conflicts sanely
ok 9 - revert conflict, diff3 -m style
# passed all 9 test(s)
1..9
