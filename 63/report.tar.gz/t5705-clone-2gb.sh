Skipping expensive 2GB clone test; enable it with GIT_TEST_CLONE_2GB=t
ok 1 # skip setup (missing CLONE_2GB)
ok 2 # skip clone - bare (missing CLONE_2GB)
ok 3 # skip clone - with worktree, file:// protocol (missing CLONE_2GB)
# passed all 3 test(s)
1..3
