ok 1 - setup
ok 2 - ref^{non-existent}
ok 3 - ref^{}
ok 4 - ref^{commit}
ok 5 - ref^{tree}
ok 6 - ref^{/}
ok 7 - ref^{/non-existent}
ok 8 - ref^{/Initial}
# passed all 8 test(s)
1..8
