ok 1 - prepare repository with topic branch
ok 2 - pick top patch from topic branch into master
ok 3 - rebase topic branch against new master and check git am did not get halted
ok 4 - rebase --merge topic branch that was partially merged upstream
# passed all 4 test(s)
1..4
