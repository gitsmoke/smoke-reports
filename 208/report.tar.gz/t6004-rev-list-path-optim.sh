ok 1 - setup
ok 2 - path-optimization
ok 3 - further setup
ok 4 - path optimization 2
# passed all 4 test(s)
1..4
