ok 1 - setup
ok 2 - ls-tree piped to mktree (1)
ok 3 - ls-tree piped to mktree (2)
ok 4 - ls-tree output in wrong order given to mktree (1)
ok 5 - ls-tree output in wrong order given to mktree (2)
ok 6 - allow missing object with --missing
ok 7 - mktree refuses to read ls-tree -r output (1)
ok 8 - mktree refuses to read ls-tree -r output (2)
# passed all 8 test(s)
1..8
