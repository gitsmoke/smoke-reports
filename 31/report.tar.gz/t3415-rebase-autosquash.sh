ok 1 - setup
ok 2 - auto fixup
ok 3 - auto squash
ok 4 - misspelled auto squash
# passed all 4 test(s)
1..4
