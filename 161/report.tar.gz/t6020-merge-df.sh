ok 1 - prepare repository
ok 2 - Merge with d/f conflicts
ok 3 - F/D conflict
ok 4 - setup modify/delete + directory/file conflict
ok 5 - modify/delete + directory/file conflict
ok 6 - modify/delete + directory/file conflict; other way
# passed all 6 test(s)
1..6
