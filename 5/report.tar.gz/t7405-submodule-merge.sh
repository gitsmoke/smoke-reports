ok 1 - setup
ok 2 - merging with modify/modify conflict
ok 3 - merging with a modify/modify conflict between merge bases
# passed all 3 test(s)
1..3
