ok 1 - Setup rename across paths each below D/F conflicts
not ok - 2 Cherry-pick succeeds with rename across D/F conflicts
#	
#		git reset --hard &&
#		git checkout master^0 &&
#		git cherry-pick branch
#	
# failed 1 among 2 test(s)
1..2
