ok 1 - setup
ok 2 - loose objects borrowed from alternate are not missing
ok 3 - HEAD is part of refs, valid objects appear valid
ok 4 - setup: helpers for corruption tests
ok 5 - object with bad sha1
ok 6 - branch pointing to non-commit
ok 7 - email without @ is okay
ok 8 - email with embedded > is not okay
ok 9 - tag pointing to nonexistent
ok 10 - tag pointing to something else than its type
ok 11 - cleaned up
# passed all 11 test(s)
1..11
