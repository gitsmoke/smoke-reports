ok 1 - set up basic repos
ok 2 - alias builtin format
ok 3 - alias masking builtin format
ok 4 - alias user-defined format
ok 5 - alias user-defined tformat
ok 6 - alias non-existant format
ok 7 - alias of an alias
ok 8 - alias masking an alias
ok 9 - alias loop
# passed all 9 test(s)
1..9
