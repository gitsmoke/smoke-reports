ok 1 - setup
ok 2 - tar archive
ok 3 - zip archive
# passed all 3 test(s)
1..3
