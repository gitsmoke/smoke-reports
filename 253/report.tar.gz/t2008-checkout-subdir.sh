ok 1 - setup
ok 2 - remove and restore with relative path
ok 3 - checkout with empty prefix
ok 4 - checkout with simple prefix
ok 5 - relative path outside tree should fail
ok 6 - incorrect relative path to file should fail (1)
ok 7 - incorrect relative path should fail (2)
ok 8 - incorrect relative path should fail (3)
# passed all 8 test(s)
1..8
