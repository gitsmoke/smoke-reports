ok 1 - setup
ok 2 - rebase --abort
ok 3 - rebase --abort after --skip
ok 4 - rebase --abort after --continue
ok 5 - rebase --merge --abort
ok 6 - rebase --merge --abort after --skip
ok 7 - rebase --merge --abort after --continue
# passed all 7 test(s)
1..7
