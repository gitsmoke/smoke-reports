ok 1 - blank line at end of file; extend at end of file
ok 2 - two blanks line at end of file; extend at end of file
ok 3 - same, but do not remove trailing spaces
ok 4 - at beginning of file
# passed all 4 test(s)
1..4
