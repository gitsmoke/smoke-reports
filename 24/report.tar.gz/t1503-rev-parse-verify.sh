ok 1 - set up basic repo with 1 file (hello) and 4 commits
ok 2 - works with one good rev
ok 3 - fails with any bad rev or many good revs
ok 4 - fails silently when using -q
ok 5 - no stdout output on error
ok 6 - use --default
# passed all 6 test(s)
1..6
