ok 1 - setup
ok 2 - naive merge fails
ok 3 - --ignore-space-change makes merge succeed
ok 4 - --ignore-space-change: our w/s-only change wins
ok 5 - --ignore-space-change: their real change wins over w/s
ok 6 - --ignore-space-change: does not ignore new spaces
ok 7 - --ignore-all-space drops their new spaces
ok 8 - --ignore-all-space keeps our new spaces
ok 9 - --ignore-space-at-eol
# passed all 9 test(s)
1..9
