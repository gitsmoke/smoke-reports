ok 1 - make history for tracking
ok 2 - clone repo with git
ok 3 - make sure r2 still has old file
# passed all 3 test(s)
1..3
