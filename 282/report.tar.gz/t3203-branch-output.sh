ok 1 - make commits
ok 2 - make branches
ok 3 - make remote branches
ok 4 - git branch shows local branches
ok 5 - git branch -r shows remote branches
ok 6 - git branch -a shows local and remote branches
ok 7 - git branch -v shows branch summaries
ok 8 - git branch shows detached HEAD properly
# passed all 8 test(s)
1..8
