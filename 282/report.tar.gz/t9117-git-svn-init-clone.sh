ok 1 - setup svnrepo
ok 2 - basic clone
ok 3 - clone to target directory
ok 4 - clone with --stdlayout
ok 5 - clone to target directory with --stdlayout
# passed all 5 test(s)
1..5
