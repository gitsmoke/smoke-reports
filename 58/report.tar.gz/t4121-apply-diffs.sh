ok 1 - setup
ok 2 - check if contextually independent diffs for the same file apply
# passed all 2 test(s)
1..2
