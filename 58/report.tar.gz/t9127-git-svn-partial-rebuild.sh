ok 1 - initialize svnrepo
ok 2 - import an early SVN revision into git
ok 3 - make full git mirror of SVN
ok 4 - fetch from git mirror and partial-rebuild
# passed all 4 test(s)
1..4
