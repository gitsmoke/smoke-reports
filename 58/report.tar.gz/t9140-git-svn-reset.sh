ok 1 - setup test repository
ok 2 - clone SVN repository with hidden directory
ok 3 - modify hidden file in SVN repo
ok 4 - fetch fails on modified hidden file
ok 5 - reset unwinds back to r1
ok 6 - refetch succeeds not ignoring any files
# passed all 6 test(s)
1..6
