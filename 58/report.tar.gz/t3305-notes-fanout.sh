ok 1 - creating many notes with git-notes
ok 2 - many notes created correctly with git-notes
ok 3 - many notes created with git-notes triggers fanout
ok 4 - deleting most notes with git-notes
ok 5 - most notes deleted correctly with git-notes
ok 6 - deleting most notes triggers fanout consolidation
# passed all 6 test(s)
1..6
