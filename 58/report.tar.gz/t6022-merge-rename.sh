ok 1 - setup
ok 2 - pull renaming branch into unrenaming one
ok 3 - pull renaming branch into another renaming one
ok 4 - pull unrenaming branch into renaming one
ok 5 - pull conflicting renames
ok 6 - interference with untracked working tree file
ok 7 - interference with untracked working tree file
ok 8 - interference with untracked working tree file
ok 9 - updated working tree file should prevent the merge
ok 10 - updated working tree file should prevent the merge
ok 11 - interference with untracked working tree file
ok 12 - merge of identical changes in a renamed file
# passed all 12 test(s)
1..12
