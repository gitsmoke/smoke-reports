ok 1 - setup
ok 2 - cross renames to be detected for regular files
ok 3 - cross renames to be detected for typechange
ok 4 - moves and renames
# passed all 4 test(s)
1..4
