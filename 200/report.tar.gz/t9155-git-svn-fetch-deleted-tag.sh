ok 1 - setup svn repo
ok 2 - fetch deleted tags from same revision with checksum error
# passed all 2 test(s)
1..2
