ok 1 - setup
ok 2 - setup expected files
ok 3 - git diff --summary -M HEAD
ok 4 - setup expected files
ok 5 - git diff --stat -M HEAD
# passed all 5 test(s)
1..5
