ok 1 - start_command reports ENOENT
# passed all 1 test(s)
1..1
