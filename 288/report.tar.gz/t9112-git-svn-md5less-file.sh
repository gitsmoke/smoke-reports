ok 1 - load svn dumpfile
ok 2 - initialize git svn
ok 3 - fetch revisions from svn
# passed all 3 test(s)
1..3
