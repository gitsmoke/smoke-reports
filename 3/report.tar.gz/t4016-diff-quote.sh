ok 1 - setup
ok 2 - git diff --summary -M HEAD
ok 3 - git diff --stat -M HEAD
# passed all 3 test(s)
1..3
