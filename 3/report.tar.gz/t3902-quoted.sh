ok 1 - setup
ok 2 - check fully quoted output from ls-files
ok 3 - check fully quoted output from diff-files
ok 4 - check fully quoted output from diff-index
ok 5 - check fully quoted output from diff-tree
ok 6 - check fully quoted output from ls-tree
ok 7 - setting core.quotepath
ok 8 - check fully quoted output from ls-files
ok 9 - check fully quoted output from diff-files
ok 10 - check fully quoted output from diff-index
ok 11 - check fully quoted output from diff-tree
ok 12 - check fully quoted output from ls-tree
# passed all 12 test(s)
1..12
