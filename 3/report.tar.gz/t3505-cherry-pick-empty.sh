ok 1 - setup
ok 2 - cherry-pick an empty commit
ok 3 - index lockfile was removed
# passed all 3 test(s)
1..3
