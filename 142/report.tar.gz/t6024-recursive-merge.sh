ok 1 - setup tests
ok 2 - combined merge conflicts
ok 3 - result contains a conflict
ok 4 - virtual trees were processed
ok 5 - refuse to merge binary files
ok 6 - mark rename/delete as unmerged
# passed all 6 test(s)
1..6
