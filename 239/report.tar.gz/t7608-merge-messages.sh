ok 1 - merge local branch
ok 2 - merge octopus branches
ok 3 - merge tag
ok 4 - ambiguous tag
ok 5 - remote-tracking branch
# passed all 5 test(s)
1..5
