ok 1 - setup
ok 2 - setup expected files
ok 3 - check fully quoted output from ls-files
ok 4 - check fully quoted output from diff-files
ok 5 - check fully quoted output from diff-index
ok 6 - check fully quoted output from diff-tree
ok 7 - check fully quoted output from ls-tree
ok 8 - setting core.quotepath
ok 9 - check fully quoted output from ls-files
ok 10 - check fully quoted output from diff-files
ok 11 - check fully quoted output from diff-index
ok 12 - check fully quoted output from diff-tree
ok 13 - check fully quoted output from ls-tree
# passed all 13 test(s)
1..13
