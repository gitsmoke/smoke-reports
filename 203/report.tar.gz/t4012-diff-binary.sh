ok 1 - prepare repository
ok 2 - diff without --binary
ok 3 - diff with --binary
ok 4 - apply detecting corrupt patch correctly
ok 5 - apply detecting corrupt patch correctly
ok 6 - initial commit
ok 7 - diff-index with --binary
ok 8 - apply binary patch
ok 9 - diff --no-index with binary creation
# passed all 9 test(s)
1..9
