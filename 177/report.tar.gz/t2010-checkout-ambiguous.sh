ok 1 - setup
ok 2 - reference must be a tree
ok 3 - branch switching
ok 4 - checkout world from the index
ok 5 - non ambiguous call
ok 6 - allow the most common case
ok 7 - check ambiguity
ok 8 - disambiguate checking out from a tree-ish
# passed all 8 test(s)
1..8
