ok 1 - setup
ok 2 - set up G and H
ok 3 - merge-base G H
ok 4 - merge-base/show-branch --independent
ok 5 - unsynchronized clocks
ok 6 - --independent with unsynchronized clocks
ok 7 - merge-base for octopus-step (setup)
ok 8 - merge-base A B C
ok 9 - criss-cross merge-base for octopus-step
# passed all 9 test(s)
1..9
