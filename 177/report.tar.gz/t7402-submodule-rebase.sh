ok 1 - setup
ok 2 - rebase with a dirty submodule
ok 3 - interactive rebase with a dirty submodule
ok 4 - rebase with dirty file and submodule fails
ok 5 - stash with a dirty submodule
# passed all 5 test(s)
1..5
