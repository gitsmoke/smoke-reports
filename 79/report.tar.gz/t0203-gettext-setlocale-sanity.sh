# lib-gettext: Found 'is_IS.utf8' as a is_IS UTF-8 locale
# lib-gettext: Found 'is_IS.iso88591' as a is_IS ISO-8859-1 locale
ok 1 - git show a ISO-8859-1 commit under C locale
ok 2 - git show a ISO-8859-1 commit under a UTF-8 locale
# passed all 2 test(s)
1..2
