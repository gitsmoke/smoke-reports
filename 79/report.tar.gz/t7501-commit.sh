ok 1 - initial status
ok 2 - Constructing initial commit
ok 3 - fail initial amend
ok 4 - initial commit
ok 5 - invalid options 1
ok 6 - invalid options 2
ok 7 - using paths with -a
ok 8 - using paths with --interactive
ok 9 - using invalid commit with -C
ok 10 - testing nothing to commit
ok 11 - next commit
ok 12 - commit message from non-existing file
ok 13 - empty commit message
ok 14 - commit message from file
ok 15 - amend commit
ok 16 - passing -m and -F
ok 17 - using message from other commit
ok 18 - editing message from other commit
ok 19 - message from stdin
ok 20 - overriding author from command line
ok 21 - commit --author output mentions author
ok 22 - interactive add
ok 23 - showing committed revisions
ok 24 - editor not invoked if -F is given
ok 25 - validate git rev-list output.
ok 26 - partial commit that involves removal (1)
ok 27 - partial commit that involves removal (2)
ok 28 - partial commit that involves removal (3)
ok 29 - amend commit to fix author
ok 30 - amend commit to fix date
ok 31 - sign off (1)
ok 32 - sign off (2)
ok 33 - signoff gap
ok 34 - signoff gap 2
ok 35 - multiple -m
ok 36 - amend commit to fix author
ok 37 - git commit <file> with dirty index
ok 38 - same tree (single parent)
ok 39 - same tree (single parent) --allow-empty
ok 40 - same tree (merge and amend merge)
ok 41 - amend using the message from another commit
ok 42 - amend using the message from a commit named with tag
ok 43 - amend can copy notes
# passed all 43 test(s)
1..43
