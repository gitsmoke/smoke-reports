ok 1 - setup for merge-preserving rebase
ok 2 - rebase -p fakes interactive rebase
ok 3 - --continue works after a conflict
# passed all 3 test(s)
1..3
