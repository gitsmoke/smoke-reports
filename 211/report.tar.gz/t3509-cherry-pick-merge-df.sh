ok 1 - Setup rename across paths each below D/F conflicts
ok 2 - Cherry-pick succeeds with rename across D/F conflicts
# passed all 2 test(s)
1..2
