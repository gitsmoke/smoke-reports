ok 1 - setup
ok 2 - cherry-pick first..fourth works
ok 3 - cherry-pick --strategy resolve first..fourth works
ok 4 - cherry-pick --ff first..fourth works
ok 5 - cherry-pick -n first..fourth works
ok 6 - revert first..fourth works
ok 7 - revert ^first fourth works
ok 8 - revert fourth fourth~1 fourth~2 works
ok 9 - cherry-pick -3 fourth works
ok 10 - cherry-pick --stdin works
# passed all 10 test(s)
1..10
