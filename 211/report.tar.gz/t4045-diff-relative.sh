ok 1 - setup
ok 2 - -p --relative=subdir/
ok 3 - -p --relative=subdir
ok 4 - -p --relative=sub
ok 5 - --stat --relative=subdir/
ok 6 - --stat --relative=subdir
ok 7 - --stat --relative=sub
ok 8 - --raw --relative=subdir/
ok 9 - --raw --relative=subdir
ok 10 - --raw --relative=sub
# passed all 10 test(s)
1..10
