ok 1 - setup
ok 2 - update-index --add beyond symlinks
ok 3 - add beyond symlinks
# passed all 3 test(s)
1..3
