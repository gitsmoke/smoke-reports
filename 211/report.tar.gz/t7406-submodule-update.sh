ok 1 - setup a submodule tree
ok 2 - submodule update detaching the HEAD 
ok 3 - submodule update --rebase staying on master
ok 4 - submodule update --merge staying on master
ok 5 - submodule update - rebase in .git/config
ok 6 - submodule update - checkout in .git/config but --rebase given
ok 7 - submodule update - merge in .git/config
ok 8 - submodule update - checkout in .git/config but --merge given
ok 9 - submodule update - checkout in .git/config
ok 10 - submodule init picks up rebase
ok 11 - submodule init picks up merge
# passed all 11 test(s)
1..11
