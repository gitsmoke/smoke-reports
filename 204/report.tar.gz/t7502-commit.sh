ok 1 - output summary format
ok 2 - output summary format: root-commit
ok 3 - output summary format for commit with an empty diff
ok 4 - output summary format for merges
ok 5 - the basics
ok 6 - partial
ok 7 - partial modification in a subdirectory
ok 8 - partial removal
ok 9 - sign off
ok 10 - multiple -m
ok 11 - verbose
ok 12 - verbose respects diff config
ok 13 - cleanup commit messages (verbatim,-t)
ok 14 - cleanup commit messages (verbatim,-F)
ok 15 - cleanup commit messages (verbatim,-m)
ok 16 - cleanup commit messages (whitespace,-F)
ok 17 - cleanup commit messages (strip,-F)
ok 18 - cleanup commit messages (strip,-F,-e)
ok 19 - cleanup commit messages (strip,-F,-e): output
ok 20 - author different from committer
ok 21 - author different from committer: output
ok 22 - committer is automatic
ok 23 - committer is automatic: output
ok 24 - do not fire editor in the presence of conflicts
ok 25 - a SIGTERM should break locks
ok 26 - Hand committing of a redundant merge removes dups
ok 27 - A single-liner subject with a token plus colon is not a footer
ok 28 - commit
ok 29 - commit
ok 30 - commit --status
ok 31 - commit --no-status
ok 32 - commit with commit.status = yes
ok 33 - commit with commit.status = no
ok 34 - commit --status with commit.status = yes
ok 35 - commit --no-status with commit.status = yes
ok 36 - commit --status with commit.status = no
ok 37 - commit --no-status with commit.status = no
ok 38 - commit
ok 39 - commit
ok 40 - commit --status
ok 41 - commit --no-status
ok 42 - commit with commit.status = yes
ok 43 - commit with commit.status = no
ok 44 - commit --status with commit.status = yes
ok 45 - commit --no-status with commit.status = yes
ok 46 - commit --status with commit.status = no
ok 47 - commit --no-status with commit.status = no
# passed all 47 test(s)
1..47
