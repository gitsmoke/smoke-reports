ok 1 - setup / mkdir
ok 2 - setup 10
ok 3 - notes work
ok 4 - notes timing with /usr/bin/time
ok 5 - teardown / cd ..
ok 6 - setup / mkdir
ok 7 - setup 100
ok 8 - notes work
ok 9 - notes timing with /usr/bin/time
ok 10 - teardown / cd ..
ok 11 - setup / mkdir
ok 12 - setup 1000
ok 13 - notes work
ok 14 - notes timing with /usr/bin/time
ok 15 - teardown / cd ..
ok 16 - setup / mkdir
ok 17 - setup 10000
ok 18 - notes work
ok 19 - notes timing with /usr/bin/time
ok 20 - teardown / cd ..
# passed all 20 test(s)
1..20
