ok 1 - branch -h
ok 2 - checkout-index -h
ok 3 - commit -h
ok 4 - gc -h
ok 5 - ls-files -h
ok 6 - merge -h
ok 7 - update-index -h
ok 8 - upload-archive -h
# passed all 8 test(s)
1..8
