ok 1 - setup (initial)
ok 2 - rename (5, ok)
ok 3 - set diff.renamelimit to 4
ok 4 - rename (4, ok)
ok 5 - rename (5, fail)
ok 6 - set merge.renamelimit to 5
ok 7 - rename (5, ok)
ok 8 - rename (6, fail)
ok 9 - setup large simple rename
ok 10 - massive simple rename does not spam added files
# passed all 10 test(s)
1..10
