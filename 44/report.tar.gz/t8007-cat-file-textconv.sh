ok 1 - setup 
ok 2 - no filter specified
ok 3 - setup textconv filters
ok 4 - cat-file without --textconv
ok 5 - cat-file without --textconv on previous commit
ok 6 - cat-file --textconv on last commit
ok 7 - cat-file --textconv on previous commit
# passed all 7 test(s)
1..7
