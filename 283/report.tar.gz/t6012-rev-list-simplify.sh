ok 1 - setup
ok 2 - log --full-history
ok 3 - log --full-history -- file
ok 4 - log --full-history --topo-order -- file
ok 5 - log --full-history --date-order -- file
ok 6 - log --simplify-merges -- file
ok 7 - log -- file
ok 8 - log --topo-order -- file
# passed all 8 test(s)
1..8
