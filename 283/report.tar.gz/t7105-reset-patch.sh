ok 1 - setup
ok 2 - saying "n" does nothing
ok 3 - git reset -p
ok 4 - git reset -p HEAD^
ok 5 - git reset -p dir
ok 6 - git reset -p -- foo (inside dir)
ok 7 - git reset -p HEAD^ -- dir
ok 8 - none of this moved HEAD
# passed all 8 test(s)
1..8
