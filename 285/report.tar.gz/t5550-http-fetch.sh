ok 1 - setup repository
ok 2 - create http-accessible bare repository
ok 3 - clone http repository
ok 4 - clone http repository with authentication
ok 5 - fetch changes via http
ok 6 - http remote detects correct HEAD
ok 7 - fetch packed objects
ok 8 - fetch notices corrupt pack
ok 9 - fetch notices corrupt idx
ok 10 - did not use upload-pack service
# passed all 10 test(s)
1..10
