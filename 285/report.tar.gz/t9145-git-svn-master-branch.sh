ok 1 - setup test repository
ok 2 - git svn clone --stdlayout sets up trunk as master
# passed all 2 test(s)
1..2
