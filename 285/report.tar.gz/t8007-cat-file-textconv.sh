ok 1 - setup 
ok 2 - no filter specified
ok 3 - setup textconv filters
ok 4 - cat-file without --textconv
ok 5 - cat-file without --textconv on previous commit
ok 6 - cat-file --textconv on last commit
ok 7 - cat-file --textconv on previous commit
ok 8 - cat-file without --textconv (symlink)
ok 9 - cat-file --textconv on index (symlink)
ok 10 - cat-file --textconv on HEAD (symlink)
# passed all 10 test(s)
1..10
