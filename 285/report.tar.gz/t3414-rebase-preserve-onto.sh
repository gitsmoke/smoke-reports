ok 1 - setup
ok 2 - rebase from B1 onto H1
ok 3 - rebase from E1 onto H1
ok 4 - rebase from C1 onto H1
# passed all 4 test(s)
1..4
