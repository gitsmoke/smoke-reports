ok 1 - basics
ok 2 - --ignore-missing --refresh
ok 3 - --unmerged --refresh
ok 4 - --ignore-submodules --refresh (1)
ok 5 - --ignore-submodules --refresh (2)
# passed all 5 test(s)
1..5
