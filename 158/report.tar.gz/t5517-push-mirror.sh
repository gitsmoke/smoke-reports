ok 1 - push mirror creates new branches
ok 2 - push mirror updates existing branches
ok 3 - push mirror force updates existing branches
ok 4 - push mirror removes branches
ok 5 - push mirror adds, updates and removes branches together
ok 6 - push mirror creates new tags
ok 7 - push mirror updates existing tags
ok 8 - push mirror force updates existing tags
ok 9 - push mirror removes tags
ok 10 - push mirror adds, updates and removes tags together
ok 11 - remote.foo.mirror adds and removes branches
ok 12 - remote.foo.mirror=no has no effect
# passed all 12 test(s)
1..12
