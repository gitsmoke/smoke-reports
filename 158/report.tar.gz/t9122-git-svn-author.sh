ok 1 - setup svn repository
ok 2 - interact with it via git svn
# passed all 2 test(s)
1..2
