ok 1 - test help
ok 2 - short options
ok 3 - long options
ok 4 - missing required value
ok 5 - intermingled arguments
ok 6 - unambiguously abbreviated option
ok 7 - unambiguously abbreviated option with "="
ok 8 - ambiguously abbreviated option
ok 9 - non ambiguous option (after two options it abbreviates)
ok 10 - detect possible typos
ok 11 - keep some options as arguments
ok 12 - OPT_DATE() and OPT_SET_PTR() work
ok 13 - OPT_CALLBACK() and OPT_BIT() work
ok 14 - OPT_CALLBACK() and callback errors work
ok 15 - OPT_BIT() and OPT_SET_INT() work
ok 16 - OPT_NEGBIT() and OPT_SET_INT() work
ok 17 - OPT_BIT() works
ok 18 - OPT_NEGBIT() works
ok 19 - OPT_BOOLEAN() with PARSE_OPT_NODASH works
ok 20 - OPT_NUMBER_CALLBACK() works
ok 21 - negation of OPT_NONEG flags is not ambiguous
# passed all 21 test(s)
1..21
