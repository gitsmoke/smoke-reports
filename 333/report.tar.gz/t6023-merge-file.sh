ok 1 - merge with no changes
ok 2 - merge without conflict
ok 3 - works in subdirectory
ok 4 - merge without conflict (--quiet)
ok 5 - merge without conflict (missing LF at EOF)
ok 6 - merge result added missing LF
ok 7 - merge with conflicts
ok 8 - expected conflict markers
ok 9 - merge with conflicts, using -L
ok 10 - expected conflict markers, with -L
ok 11 - conflict in removed tail
ok 12 - expected conflict markers
ok 13 - binary files cannot be merged
ok 14 - MERGE_ZEALOUS simplifies non-conflicts
ok 15 - ZEALOUS_ALNUM
ok 16 - "diff3 -m" style output (1)
ok 17 - "diff3 -m" style output (2)
ok 18 - marker size
# passed all 18 test(s)
1..18
