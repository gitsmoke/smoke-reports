ok 1 - setup repository
ok 2 - create http-accessible bare repository
ok 3 - clone http repository
ok 4 - clone http repository with authentication
ok 5 - fetch changes via http
ok 6 - fetch changes via manual http-fetch
ok 7 - http remote detects correct HEAD
ok 8 - fetch packed objects
ok 9 - fetch notices corrupt pack
ok 10 - fetch notices corrupt idx
ok 11 - did not use upload-pack service
# passed all 11 test(s)
1..11
