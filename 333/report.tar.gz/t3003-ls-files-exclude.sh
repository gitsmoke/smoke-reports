ok 1 - create repo with file
ok 2 - ls-files output contains file (cached)
ok 3 - ls-files output contains file (modified)
ok 4 - add file to gitignore
ok 5 - ls-files output contains file (cached)
ok 6 - ls-files output contains file (modified)
ok 7 - ls-files -i lists only tracked-but-ignored files
# passed all 7 test(s)
1..7
