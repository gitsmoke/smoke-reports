ok 1 - setup 
ok 2 - setup: expected output
ok 3 - ls-files --others
ok 4 - ls-files --others --directory
ok 5 - --no-empty-directory hides empty directory
# passed all 5 test(s)
1..5
