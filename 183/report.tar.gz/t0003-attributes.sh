ok 1 - setup
ok 2 - attribute test
ok 3 - core.attributesfile
ok 4 - attribute test: read paths from stdin
ok 5 - root subdir attribute test
ok 6 - setup bare
ok 7 - bare repository: check that .gitattribute is ignored
ok 8 - bare repository: test info/attributes
# passed all 8 test(s)
1..8
