ok 1 - setup
ok 2 - "reset <submodule>" updates the index
ok 3 - "checkout <submodule>" updates the index only
# passed all 3 test(s)
1..3
