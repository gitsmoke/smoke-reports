ok 1 - setup
ok 2 - 1st pull
ok 3 - post 1st pull setup
ok 4 - 2nd pull
ok 5 - 3rd pull
ok 6 - clone shallow
ok 7 - clone shallow object count
ok 8 - clone shallow object count (part 2)
ok 9 - fsck in shallow repo
ok 10 - simple fetch in shallow repo
ok 11 - no changes expected
ok 12 - fetch same depth in shallow repo
ok 13 - no changes expected
ok 14 - add two more
ok 15 - pull in shallow repo
ok 16 - clone shallow object count
ok 17 - add two more (part 2)
ok 18 - deepening pull in shallow repo
ok 19 - clone shallow object count
ok 20 - deepening fetch in shallow repo
ok 21 - clone shallow object count
ok 22 - pull in shallow repo with missing merge base
ok 23 - additional simple shallow deepenings
ok 24 - clone shallow object count
ok 25 - infinite deepening (full repo)
# passed all 25 test(s)
1..25
