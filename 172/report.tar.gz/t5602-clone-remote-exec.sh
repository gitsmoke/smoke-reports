ok 1 - setup
ok 2 - clone calls git upload-pack unqualified with no -u option
ok 3 - clone calls specified git upload-pack with -u option
# passed all 3 test(s)
1..3
