ok 1 - git apply (1)
ok 2 - git apply (2)
ok 3 - git apply (3)
# passed all 3 test(s)
1..3
