ok 1 - setup bare parent
ok 2 - setup local commit
ok 3 - push -u master:master
ok 4 - push -u master:other
ok 5 - push -u --dry-run master:otherX
ok 6 - push -u master2:master2
ok 7 - push -u master2:other2
ok 8 - push -u :master2
ok 9 - push -u --all
ok 10 - push -u HEAD
ok 11 - progress messages to non-tty
ok 12 - progress messages to non-tty (forced)
# passed all 12 test(s)
1..12
