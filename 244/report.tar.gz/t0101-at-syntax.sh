ok 1 - setup
ok 2 - @{0} shows current
ok 3 - @{1} shows old
ok 4 - @{now} shows current
ok 5 - @{2001-09-17} (before the first commit) shows old
ok 6 - silly approxidates work
ok 7 - notice misspelled upstream
ok 8 - complain about total nonsense
# passed all 8 test(s)
1..8
