ok 1 - setup
ok 2 - apply without --reject should fail
ok 3 - apply without --reject should fail
ok 4 - apply with --reject should fail but update the file
ok 5 - apply with --reject should fail but update the file
ok 6 - the same test with --verbose
ok 7 - apply cleanly with --verbose
# passed all 7 test(s)
1..7
