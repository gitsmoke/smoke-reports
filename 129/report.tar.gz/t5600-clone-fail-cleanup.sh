ok 1 - clone of non-existent source should fail
ok 2 - failed clone should not leave a directory
ok 3 - clone of non-existent (relative to $PWD) source should fail
ok 4 - clone should work now that source exists
ok 5 - successful clone must leave the directory
# passed all 5 test(s)
1..5
