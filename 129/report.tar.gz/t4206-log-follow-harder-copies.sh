ok 1 - add a file path0 and commit.
ok 2 - Change path0.
ok 3 - copy path0 to path1.
ok 4 - find the copy path0 -> path1 harder
ok 5 - validate the output.
# passed all 5 test(s)
1..5
