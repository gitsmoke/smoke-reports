ok 1 - setup
ok 2 - fetch recurses into submodules
ok 3 - fetch --no-recursive only fetches superproject
ok 4 - using fetch=false in .gitmodules only fetches superproject
ok 5 - --recursive overrides .gitmodules config
ok 6 - using fetch=true in .git/config overrides setting in .gitmodules
ok 7 - --no-recursive overrides fetch setting from .git/config
# passed all 7 test(s)
1..7
