ok 1 - setup
ok 2 - git commit --amend
ok 3 - git commit --amend --no-post-rewrite
ok 4 - git rebase
ok 5 - git rebase --skip
ok 6 - git rebase -m
ok 7 - git rebase -m --skip
ok 8 - git rebase -i (unchanged)
ok 9 - git rebase -i (skip)
ok 10 - git rebase -i (squash)
ok 11 - git rebase -i (fixup without conflict)
ok 12 - git rebase -i (double edit)
# passed all 12 test(s)
1..12
