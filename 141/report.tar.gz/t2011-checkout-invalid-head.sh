ok 1 - setup
ok 2 - checkout should not start branch from a tree
ok 3 - checkout master from invalid HEAD
# passed all 3 test(s)
1..3
