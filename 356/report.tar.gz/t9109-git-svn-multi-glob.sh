ok 1 - test refspec globbing
ok 2 - test left-hand-side only globbing
ok 3 - test another branch
ok 4 - test disallow multiple globs
# passed all 4 test(s)
1..4
