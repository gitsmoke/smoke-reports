define NO_SVN_TESTS to skip git svn tests
ok 1 - initialize source svn repo
ok 2 - clone svn repo
ok 3 - change svn:mergeinfo
ok 4 - verify svn:mergeinfo
# passed all 4 test(s)
1..4
