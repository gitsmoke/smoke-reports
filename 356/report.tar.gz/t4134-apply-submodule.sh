ok 1 - setup
ok 2 - removing a submodule also removes all leading subdirectories
# passed all 2 test(s)
1..2
