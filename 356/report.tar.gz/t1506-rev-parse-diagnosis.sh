ok 1 - set up basic repo
ok 2 - correct file objects
ok 3 - correct relative file objects (0)
ok 4 - correct relative file objects (1)
ok 5 - correct relative file objects (2)
ok 6 - correct relative file objects (3)
ok 7 - correct relative file objects (4)
ok 8 - correct relative file objects (5)
ok 9 - correct relative file objects (6)
ok 10 - incorrect revision id
ok 11 - incorrect file in sha1:path
ok 12 - incorrect file in :path and :N:path
ok 13 - invalid @{n} reference
ok 14 - relative path not found
ok 15 - relative path outside worktree
ok 16 - relative path when cwd is outside worktree
ok 17 - relative path when startup_info is NULL
# passed all 17 test(s)
1..17
