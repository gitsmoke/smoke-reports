ok 1 - added submodule
ok 2 - modified submodule(forward)
ok 3 - modified submodule(forward), --files
ok 4 - modified submodule(backward)
ok 5 - modified submodule(backward and forward)
ok 6 - --summary-limit
ok 7 - typechanged submodule(submodule->blob), --cached
ok 8 - typechanged submodule(submodule->blob), --files
ok 9 - typechanged submodule(submodule->blob)
ok 10 - nonexistent commit
ok 11 - typechanged submodule(blob->submodule)
ok 12 - deleted submodule
ok 13 - multiple submodules
ok 14 - path filter
ok 15 - given commit
ok 16 - --for-status
ok 17 - fail when using --files together with --cached
ok 18 - should not fail in an empty repo
# passed all 18 test(s)
1..18
