ok 1 - gc empty repository
ok 2 - gc --gobbledegook
ok 3 - gc -h with invalid configuration
# passed all 3 test(s)
1..3
