ok 1 - determine default pager
ok 2 - setup
ok 3 - git grep -O
ok 4 - git grep -O --cached
ok 5 - git grep -O --no-index
ok 6 - setup: fake "less"
ok 7 - git grep -O jumps to line in less
ok 8 - modified file
ok 9 - copes with color settings
ok 10 - run from subdir
# passed all 10 test(s)
1..10
