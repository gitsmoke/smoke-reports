ok 1 - setup
ok 2 - git add (absolute)
ok 3 - git add (funny relative)
ok 4 - git rm (absolute)
ok 5 - git rm (funny relative)
ok 6 - git ls-files (absolute)
ok 7 - git ls-files (relative #1)
ok 8 - git ls-files (relative #2)
ok 9 - git ls-files (relative #3)
ok 10 - commit using absolute path names
ok 11 - log using absolute path names
ok 12 - blame using absolute path names
ok 13 - setup deeper work tree
ok 14 - add a directory outside the work tree
ok 15 - add a file outside the work tree, nasty case 1
ok 16 - add a file outside the work tree, nasty case 2
# passed all 16 test(s)
1..16
