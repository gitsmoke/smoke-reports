ok 1 - load svk depot
ok 2 - svk merges were represented coming in
# passed all 2 test(s)
1..2
