ok 1 - prepare reference tree
ok 2 - prepare work tree
ok 3 - copy detection
ok 4 - copy detection, cached
ok 5 - copy, limited to a subtree
ok 6 - tweak work tree
ok 7 - rename detection
ok 8 - rename, limited to a subtree
# passed all 8 test(s)
1..8
