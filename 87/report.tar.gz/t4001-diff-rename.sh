ok 1 - update-index --add a file.
ok 2 - write that tree.
ok 3 - renamed and edited the file.
ok 4 - git diff-index -p -M after rename and editing.
ok 5 - validate the output.
ok 6 - favour same basenames over different ones
ok 7 - favour same basenames even with minor differences
# passed all 7 test(s)
1..7
