ok 1 - setup
ok 2 - rebase -m
ok 3 - rebase --stat
ok 4 - rebase w/config rebase.stat
ok 5 - rebase -n overrides config rebase.stat config
# passed all 5 test(s)
1..5
