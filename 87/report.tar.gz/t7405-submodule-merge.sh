ok 1 - setup
ok 2 - setup for merge search
ok 3 - merge with one side as a fast-forward of the other
ok 4 - merging should conflict for non fast-forward
ok 5 - merging should fail for ambiguous common parent
ok 6 - merging should fail for changes that are backwards
ok 7 - merging with a modify/modify conflict between merge bases
# passed all 7 test(s)
1..7
