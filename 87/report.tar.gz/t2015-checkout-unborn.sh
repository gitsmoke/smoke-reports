ok 1 - setup
ok 2 - checkout from unborn preserves untracked files
ok 3 - checkout from unborn preserves index contents
ok 4 - checkout from unborn merges identical index contents
# passed all 4 test(s)
1..4
