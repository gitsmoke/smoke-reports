ok 1 - setup
ok 2 - have symlink in place where dir is expected.
ok 3 - use --prefix=path2/
ok 4 - use --prefix=tmp-
ok 5 - use --prefix=tmp- but with a conflicting file and dir
ok 6 - use --prefix=tmp/orary/ where tmp is a symlink
ok 7 - use --prefix=tmp/orary- where tmp is a symlink
ok 8 - use --prefix=tmp- where tmp-path1 is a symlink
# passed all 8 test(s)
1..8
