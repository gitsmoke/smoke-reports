# passed all 0 test(s)
1..0 # SKIP skipping test, USE_CURL_MULTI is not defined
