ok 1 - setup
ok 2 - first textconv works
ok 3 - cached textconv produces same output
ok 4 - cached textconv does not run helper
ok 5 - changing textconv invalidates cache
ok 6 - switching diff driver produces correct results
# passed all 6 test(s)
1..6
