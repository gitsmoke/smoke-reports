ok 1 - setup
ok 2 - gitdir selection on normal repos
ok 3 - gitdir selection on unsupported repo
ok 4 - gitdir not required mode
ok 5 - gitdir required mode
# passed all 5 test(s)
1..5
