ok 1 - test preparation: write empty tree
ok 2 - construct commit
ok 3 - read commit
ok 4 - compare commit
# passed all 4 test(s)
1..4
