ok 1 - setup
ok 2 - plain, git-style file creation patch
ok 3 - plain, traditional patch
ok 4 - plain, traditional file creation patch
ok 5 - with spaces, git-style file creation patch
ok 6 - with spaces, traditional patch
ok 7 - with spaces, traditional file creation patch
ok 8 - with tab, git-style file creation patch
ok 9 - with tab, traditional patch
ok 10 - with tab, traditional file creation patch
ok 11 - with backslash, git-style file creation patch
ok 12 - with backslash, traditional patch
ok 13 - with backslash, traditional file creation patch
ok 14 - with quote, git-style file creation patch
not ok 15 - with quote, traditional patch # TODO known breakage
ok 16 - with quote, traditional file creation patch
ok 17 - whitespace-damaged traditional patch
ok 18 - traditional patch with colon in timezone
ok 19 - traditional, whitespace-damaged, colon in timezone
# still have 1 known breakage(s)
# passed all remaining 18 test(s)
1..19
