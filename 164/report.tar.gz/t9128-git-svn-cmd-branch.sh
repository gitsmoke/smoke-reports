ok 1 - initialize svnrepo
ok 2 - import into git
ok 3 - git svn branch tests
ok 4 - branch uses correct svn-remote
# passed all 4 test(s)
1..4
