ok 1 - prepare repository with topic branch, and check cherry finds the 2 patches from there
ok 2 - check that cherry with limit returns only the top patch
ok 3 - cherry-pick one of the 2 patches, and check cherry recognized one and only one as new
# passed all 3 test(s)
1..3
