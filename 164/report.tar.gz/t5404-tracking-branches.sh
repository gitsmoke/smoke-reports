ok 1 - setup
ok 2 - prepare pushable branches
ok 3 - mixed-success push returns error
ok 4 - check tracking branches updated correctly after push
ok 5 - check tracking branches not updated for failed refs
ok 6 - deleted branches have their tracking branches removed
ok 7 - already deleted tracking branches ignored
# passed all 7 test(s)
1..7
