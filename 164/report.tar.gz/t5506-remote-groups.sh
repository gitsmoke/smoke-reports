ok 1 - setup
ok 2 - no group updates all
ok 3 - nonexistant group produces error
ok 4 - updating group updates all members (remote update)
ok 5 - updating group updates all members (fetch)
ok 6 - updating group does not update non-members (remote update)
ok 7 - updating group does not update non-members (fetch)
ok 8 - updating remote name updates that remote
# passed all 8 test(s)
1..8
