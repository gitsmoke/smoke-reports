ok 1 - setup
ok 2 - one is ancestor of others and should not be shown
# passed all 2 test(s)
1..2
