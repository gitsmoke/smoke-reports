ok 1 - load svm repo
ok 2 - verify metadata for /bar
ok 3 - verify metadata for /dir/a/b/c/d/e
ok 4 - verify metadata for /dir
ok 5 - find commit based on SVN revision number
ok 6 - empty rebase
# passed all 6 test(s)
1..6
