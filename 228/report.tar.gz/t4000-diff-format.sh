ok 1 - update-index --add two files with and without +x.
ok 2 - git diff-files -p after editing work tree.
ok 3 - validate git diff-files -p output.
# passed all 3 test(s)
1..3
