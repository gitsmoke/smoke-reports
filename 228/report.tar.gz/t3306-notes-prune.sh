ok 1 - setup: create a few commits with notes
ok 2 - verify commits and notes
ok 3 - remove some commits
ok 4 - verify that commits are gone
ok 5 - verify that notes are still present
ok 6 - prune -n does not remove notes
ok 7 - prune -n lists prunable notes
ok 8 - prune notes
ok 9 - verify that notes are gone
ok 10 - remove some commits
ok 11 - prune -v notes
ok 12 - verify that notes are gone
# passed all 12 test(s)
1..12
