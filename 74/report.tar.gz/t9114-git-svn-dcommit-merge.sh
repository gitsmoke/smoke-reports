ok 1 - setup svn repository
ok 2 - setup git mirror and merge
ok 3 - verify pre-merge ancestry
ok 4 - git svn dcommit merges
ok 5 - verify post-merge ancestry
ok 6 - verify merge commit message
# passed all 6 test(s)
1..6
