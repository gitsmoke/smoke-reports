ok 1 - test refspec globbing
ok 2 - test left-hand-side only globbing
ok 3 - test disallow multi-globs
# passed all 3 test(s)
1..3
