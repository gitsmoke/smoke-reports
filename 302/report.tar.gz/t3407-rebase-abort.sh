ok 1 - setup
ok 2 - rebase --abort
ok 3 - rebase --abort after --skip
ok 4 - rebase --abort after --continue
ok 5 - rebase --abort does not update reflog
ok 6 - rebase --merge --abort
ok 7 - rebase --merge --abort after --skip
ok 8 - rebase --merge --abort after --continue
ok 9 - rebase --merge --abort does not update reflog
# passed all 9 test(s)
1..9
