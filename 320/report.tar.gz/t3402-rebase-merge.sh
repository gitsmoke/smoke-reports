ok 1 - setup
ok 2 - reference merge
ok 3 - rebase
ok 4 - test-rebase@{1} is pre rebase
ok 5 - merge and rebase should match
ok 6 - rebase the other way
ok 7 - rebase -Xtheirs
ok 8 - merge and rebase should match
ok 9 - picking rebase
ok 10 - rebase -s funny -Xopt
# passed all 10 test(s)
1..10
