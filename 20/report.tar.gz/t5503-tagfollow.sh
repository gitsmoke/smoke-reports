ok 1 - setup
ok 2 - fetch A (new commit : 1 connection)
ok 3 - create tag T on A, create C on branch cat
ok 4 - fetch C, T (new branch, tag : 1 connection)
ok 5 - create commits O, B, tag S on B
ok 6 - fetch B, S (commit and tag : 1 connection)
ok 7 - new clone fetch master and tags
# passed all 7 test(s)
1..7
