ok 1 - setup
ok 2 - pack the source repository
ok 3 - pack the destination repository
ok 4 - refuse pushing rewound head without --force
ok 5 - push can be used to delete a ref
ok 6 - refuse deleting push with denyDeletes
ok 7 - denyNonFastforwards trumps --force
ok 8 - push --all excludes remote tracking hierarchy
ok 9 - pushing explicit refspecs respects forcing
ok 10 - pushing wildcard refspecs respects forcing
ok 11 - deny pushing to delete current branch
# passed all 11 test(s)
1..11
