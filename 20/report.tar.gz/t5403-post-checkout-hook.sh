ok 1 - setup
ok 2 - post-checkout runs as expected 
ok 3 - post-checkout receives the right arguments with HEAD unchanged 
ok 4 - post-checkout runs as expected 
ok 5 - post-checkout args are correct with git checkout -b 
ok 6 - post-checkout receives the right args with HEAD changed 
ok 7 - post-checkout receives the right args when not switching branches 
ok 8 - post-checkout hook is triggered by clone
# passed all 8 test(s)
1..8
