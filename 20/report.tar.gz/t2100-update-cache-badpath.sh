ok 1 - git update-index --add to add various paths.
ok 2 - git update-index to add conflicting path path0/file0 should fail.
ok 3 - git update-index to add conflicting path path1/file1 should fail.
ok 4 - git update-index to add conflicting path path2 should fail.
ok 5 - git update-index to add conflicting path path3 should fail.
# passed all 5 test(s)
1..5
