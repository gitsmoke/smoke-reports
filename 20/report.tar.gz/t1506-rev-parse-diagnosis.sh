ok 1 - set up basic repo
ok 2 - correct file objects
ok 3 - incorrect revision id
ok 4 - incorrect file in sha1:path
ok 5 - incorrect file in :path and :N:path
# passed all 5 test(s)
1..5
