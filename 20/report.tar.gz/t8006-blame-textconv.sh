ok 1 - setup 
ok 2 - no filter specified
ok 3 - setup textconv filters
ok 4 - blame with --no-textconv
ok 5 - basic blame on last commit
ok 6 - blame --textconv going through revisions
ok 7 - make a new commit
ok 8 - blame from previous revision
# passed all 8 test(s)
1..8
