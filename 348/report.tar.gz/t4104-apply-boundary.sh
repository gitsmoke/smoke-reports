ok 1 - setup
ok 2 - apply add-a-patch with context
ok 3 - apply add-z-patch with context
ok 4 - apply insert-a-patch with context
ok 5 - apply mod-a-patch with context
ok 6 - apply mod-z-patch with context
ok 7 - apply del-a-patch with context
ok 8 - apply del-z-patch with context
ok 9 - apply add-a-patch without context
ok 10 - apply add-z-patch without context
ok 11 - apply insert-a-patch without context
ok 12 - apply mod-a-patch without context
ok 13 - apply mod-z-patch without context
ok 14 - apply del-a-patch without context
ok 15 - apply del-z-patch without context
ok 16 - apply non-git add-a-patch without context
ok 17 - apply non-git add-z-patch without context
ok 18 - apply non-git insert-a-patch without context
ok 19 - apply non-git mod-a-patch without context
ok 20 - apply non-git mod-z-patch without context
ok 21 - apply non-git del-a-patch without context
ok 22 - apply non-git del-z-patch without context
ok 23 - two lines
ok 24 - apply patch with 3 context lines matching at end
# passed all 24 test(s)
1..24
