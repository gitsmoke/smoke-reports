ok 1 - setup
ok 2 - no complaints for unignored file
ok 3 - no complaints for unignored dir/file
ok 4 - no complaints for unignored dir
ok 5 - no complaints for unignored d*
ok 6 - complaints for ignored ign
ok 7 - complaints for ignored ign with unignored file
ok 8 - complaints for ignored dir/ign
ok 9 - complaints for ignored dir/ign with unignored file
ok 10 - complaints for ignored dir/sub
ok 11 - complaints for ignored dir/sub with unignored file
ok 12 - complaints for ignored dir/sub/ign
ok 13 - complaints for ignored dir/sub/ign with unignored file
ok 14 - complaints for ignored sub/file
ok 15 - complaints for ignored sub/file with unignored file
ok 16 - complaints for ignored sub
ok 17 - complaints for ignored sub with unignored file
ok 18 - complaints for ignored sub/file
ok 19 - complaints for ignored sub/file with unignored file
ok 20 - complaints for ignored sub/ign
ok 21 - complaints for ignored sub/ign with unignored file
ok 22 - complaints for ignored sub in dir
ok 23 - complaints for ignored sub/file in dir
ok 24 - complaints for ignored sub/ign in dir
ok 25 - complaints for ignored ign in sub
ok 26 - complaints for ignored file in sub
# passed all 26 test(s)
1..26
