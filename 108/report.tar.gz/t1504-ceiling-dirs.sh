ok 1 - no_ceil
ok 2 - ceil_empty
ok 3 - ceil_at_parent
ok 4 - ceil_at_parent_slash
ok 5 - ceil_at_trash
ok 6 - ceil_at_trash_slash
ok 7 - ceil_at_sub
ok 8 - ceil_at_sub_slash
ok 9 - subdir_no_ceil
ok 10 - subdir_ceil_empty
ok 11 - subdir_ceil_at_trash: prefix
ok 12 - subdir_ceil_at_trash_slash: prefix
ok 13 - subdir_ceil_at_sub: prefix
ok 14 - subdir_ceil_at_sub_slash: prefix
ok 15 - subdir_ceil_at_subdir
ok 16 - subdir_ceil_at_subdir_slash
ok 17 - subdir_ceil_at_su
ok 18 - subdir_ceil_at_su_slash
ok 19 - subdir_ceil_at_sub_di
ok 20 - subdir_ceil_at_sub_di_slash
ok 21 - subdir_ceil_at_subdi
ok 22 - subdir_ceil_at_subdi_slash
ok 23 - second_of_two: prefix
ok 24 - first_of_two: prefix
ok 25 - second_of_three: prefix
ok 26 - git_dir_specified
ok 27 - sd_no_ceil
ok 28 - sd_ceil_empty
ok 29 - sd_ceil_at_trash: prefix
ok 30 - sd_ceil_at_trash_slash: prefix
ok 31 - sd_ceil_at_s: prefix
ok 32 - sd_ceil_at_s_slash: prefix
ok 33 - sd_ceil_at_sd
ok 34 - sd_ceil_at_sd_slash
ok 35 - sd_ceil_at_su
ok 36 - sd_ceil_at_su_slash
ok 37 - sd_ceil_at_s_di
ok 38 - sd_ceil_at_s_di_slash
ok 39 - sd_ceil_at_sdi
ok 40 - sd_ceil_at_sdi_slash
# passed all 40 test(s)
1..40
