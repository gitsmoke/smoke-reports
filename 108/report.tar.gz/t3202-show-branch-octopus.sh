ok 1 - setup
ok 2 - show-branch with more than 8 branches
ok 3 - show-branch with showbranch.default
# passed all 3 test(s)
1..3
