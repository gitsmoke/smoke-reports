ok 1 - ISO8859-1 setup
ok 2 - eucJP setup
ok 3 - ISO-2022-JP setup
ok 4 - ISO8859-1 commit on git side
ok 5 - eucJP commit on git side
ok 6 - ISO-2022-JP commit on git side
ok 7 - ISO8859-1 dcommit to svn
ok 8 - eucJP dcommit to svn
ok 9 - ISO-2022-JP dcommit to svn
ok 10 - ISO-8859-1 should match UTF-8 in svn
ok 11 - eucJP should match UTF-8 in svn
ok 12 - ISO-2022-JP should match UTF-8 in svn
# passed all 12 test(s)
1..12
