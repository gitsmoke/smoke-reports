ok 1 - setup
ok 2 - apply --build-fake-ancestor
ok 3 - apply --build-fake-ancestor in a subdirectory
# passed all 3 test(s)
1..3
