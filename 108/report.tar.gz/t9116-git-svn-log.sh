ok 1 - setup repository and import
ok 2 - run log
ok 3 - run log against a from trunk
ok 4 - test ascending revision range
ok 5 - test descending revision range
ok 6 - test ascending revision range with unreachable revision
ok 7 - test descending revision range with unreachable revision
ok 8 - test ascending revision range with unreachable upper boundary revision and 1 commit
ok 9 - test descending revision range with unreachable upper boundary revision and 1 commit
ok 10 - test ascending revision range with unreachable lower boundary revision and 1 commit
ok 11 - test descending revision range with unreachable lower boundary revision and 1 commit
ok 12 - test ascending revision range with unreachable boundary revisions and no commits
ok 13 - test descending revision range with unreachable boundary revisions and no commits
ok 14 - test ascending revision range with unreachable boundary revisions and 1 commit
ok 15 - test descending revision range with unreachable boundary revisions and 1 commit
# passed all 15 test(s)
1..15
