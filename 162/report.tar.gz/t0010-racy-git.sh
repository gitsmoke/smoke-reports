ok 1 - Racy GIT trial #0 part A
ok 2 - Racy GIT trial #0 part B
ok 3 - Racy GIT trial #1 part A
ok 4 - Racy GIT trial #1 part B
ok 5 - Racy GIT trial #2 part A
ok 6 - Racy GIT trial #2 part B
ok 7 - Racy GIT trial #3 part A
ok 8 - Racy GIT trial #3 part B
ok 9 - Racy GIT trial #4 part A
ok 10 - Racy GIT trial #4 part B
# passed all 10 test(s)
1..10
