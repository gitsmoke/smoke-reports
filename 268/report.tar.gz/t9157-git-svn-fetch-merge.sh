ok 1 - initialize source svn repo
ok 2 - clone svn repo
ok 3 - verify merge commit
# passed all 3 test(s)
1..3
