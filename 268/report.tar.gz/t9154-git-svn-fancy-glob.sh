ok 1 - load svn repo
ok 2 - add red branch
ok 3 - add green branch
ok 4 - add all branches
# passed all 4 test(s)
1..4
