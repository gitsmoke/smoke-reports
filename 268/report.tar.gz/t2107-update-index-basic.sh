ok 1 - update-index --nonsense fails
ok 2 - update-index --nonsense dumps usage # TODO known breakage
ok 3 - update-index -h with corrupt index
# fixed 1 known breakage(s)
# passed all 3 test(s)
1..3
