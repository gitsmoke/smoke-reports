ok 1 - setup
ok 2 - rewind
ok 3 - corrupt and check
ok 4 - reflog expire --dry-run should not touch reflog
ok 5 - reflog expire
ok 6 - prune and fsck
ok 7 - recover and check
ok 8 - delete
ok 9 - rewind2
ok 10 - --expire=never
ok 11 - gc.reflogexpire=never
ok 12 - gc.reflogexpire=false
# passed all 12 test(s)
1..12
