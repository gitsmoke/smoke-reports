ok 1 - setup
ok 2 - tags can be excluded by rev-list options
not ok 3 - bundle --stdin # TODO known breakage
not ok 4 - bundle --stdin <rev-list options> # TODO known breakage
# still have 2 known breakage(s)
# passed all remaining 2 test(s)
1..4
