Unable to use setfacl (output: 'setfacl: .: Operation not supported'; return code: '1')
ok 1 # skip Setup test repo (missing SETFACL of SETFACL)
ok 2 # skip Objects creation does not break ACLs with restrictive umask (missing SETFACL of SETFACL)
ok 3 # skip git gc does not break ACLs with restrictive umask (missing SETFACL of SETFACL)
# passed all 3 test(s)
1..3
