ok 1 - checkout working copy from svn
ok 2 - setup some commits to svn
ok 3 - initialize git svn
ok 4 - fetch revisions from svn
ok 5 - test svn:keywords ignoring
ok 6 - raw $Id$ found in kw.c
ok 7 - propset CR on crlf files
ok 8 - fetch and pull latest from svn and checkout a new wc
ok 9 - Comparing crlf
ok 10 - Comparing ne_crlf
ok 11 - Comparing lf
ok 12 - Comparing ne_lf
ok 13 - Comparing cr
ok 14 - Comparing ne_cr
ok 15 - Comparing empty_cr
ok 16 - Comparing empty_lf
ok 17 - Comparing empty
ok 18 - Comparing empty_crlf
ok 19 - Set CRLF on cr files
ok 20 - fetch and pull latest from svn
ok 21 - CRLF + $Id$
ok 22 - CRLF + $Id$ (no newline)
ok 23 - test show-ignore
ok 24 - test create-ignore
ok 25 - test propget
ok 26 - test proplist
# passed all 26 test(s)
1..26
