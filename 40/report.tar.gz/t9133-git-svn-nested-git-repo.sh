ok 1 - setup repo with a git repo inside it
ok 2 - clone an SVN repo containing a git repo
ok 3 - SVN-side change outside of .git
ok 4 - update git svn-cloned repo
ok 5 - SVN-side change inside of .git
ok 6 - update git svn-cloned repo
ok 7 - SVN-side change in and out of .git
ok 8 - update git svn-cloned repo again
# passed all 8 test(s)
1..8
