ok 1 - setup
ok 2 - apply should fail gracefully
# passed all 2 test(s)
1..2
