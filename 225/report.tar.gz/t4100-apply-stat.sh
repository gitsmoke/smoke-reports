ok 1 - rename
ok 2 - rename with recount
ok 3 - copy
ok 4 - copy with recount
ok 5 - rewrite
ok 6 - rewrite with recount
ok 7 - mode
ok 8 - mode with recount
ok 9 - non git (1)
ok 10 - non git (1) with recount
ok 11 - non git (2)
ok 12 - non git (2) with recount
ok 13 - non git (3)
ok 14 - non git (3) with recount
ok 15 - incomplete (1)
ok 16 - incomplete (1) with recount
ok 17 - incomplete (2)
ok 18 - incomplete (2) with recount
# passed all 18 test(s)
1..18
