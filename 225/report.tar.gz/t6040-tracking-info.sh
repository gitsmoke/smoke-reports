ok 1 - setup
ok 2 - branch -v
ok 3 - checkout
ok 4 - checkout with local tracked branch
ok 5 - status
ok 6 - status when tracking lightweight tags
ok 7 - status when tracking annotated tags
ok 8 - setup tracking with branch --set-upstream on existing branch
ok 9 - --set-upstream does not change branch
# passed all 9 test(s)
1..9
