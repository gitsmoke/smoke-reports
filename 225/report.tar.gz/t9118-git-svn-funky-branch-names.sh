ok 1 - setup svnrepo
ok 2 - test clone with funky branch names
ok 3 - test dcommit to funky branch
ok 4 - test dcommit to scary branch
ok 5 - test dcommit to trailing_dotlock branch
# passed all 5 test(s)
1..5
