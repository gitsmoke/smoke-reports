ok 1 - initialize git svn
ok 2 - enable auto-props config
ok 3 - add files matching auto-props
ok 4 - disable auto-props config
ok 5 - add files matching disabled auto-props
ok 6 - check resulting svn repository
ok 7 - check renamed file
# passed all 7 test(s)
1..7
