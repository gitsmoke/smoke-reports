ok 1 - setup repository and import
ok 2 - info
ok 3 - info --url
ok 4 - info .
ok 5 - info --url .
ok 6 - info file
ok 7 - info --url file
ok 8 - info directory
ok 9 - info inside directory
ok 10 - info --url directory
ok 11 - info symlink-file
ok 12 - info --url symlink-file
ok 13 - info symlink-directory
ok 14 - info --url symlink-directory
ok 15 - info added-file
ok 16 - info --url added-file
ok 17 - info added-directory
ok 18 - info --url added-directory
ok 19 - info added-symlink-file
ok 20 - info --url added-symlink-file
ok 21 - info added-symlink-directory
ok 22 - info --url added-symlink-directory
ok 23 - info deleted-file
ok 24 - info --url file (deleted)
ok 25 - info deleted-directory
ok 26 - info --url directory (deleted)
ok 27 - info deleted-symlink-file
ok 28 - info --url symlink-file (deleted)
ok 29 - info deleted-symlink-directory
ok 30 - info --url symlink-directory (deleted)
ok 31 - info unknown-file
ok 32 - info --url unknown-file
ok 33 - info unknown-directory
ok 34 - info --url unknown-directory
ok 35 - info unknown-symlink-file
ok 36 - info --url unknown-symlink-file
ok 37 - info unknown-symlink-directory
ok 38 - info --url unknown-symlink-directory
# passed all 38 test(s)
1..38
