ok 1 - setup 1
ok 2 - setup 2
ok 3 - setup 3
ok 4 - setup 4
ok 5 - setup 5
ok 6 - setup 6
ok 7 - setup 7
ok 8 - merge-recursive simple
ok 9 - merge-recursive result
ok 10 - fail if the index has unresolved entries
ok 11 - merge-recursive remove conflict
ok 12 - merge-recursive remove conflict
ok 13 - merge-recursive d/f simple
ok 14 - merge-recursive result
ok 15 - merge-recursive d/f conflict
ok 16 - merge-recursive d/f conflict result
ok 17 - merge-recursive d/f conflict the other way
ok 18 - merge-recursive d/f conflict result the other way
ok 19 - merge-recursive d/f conflict
ok 20 - merge-recursive d/f conflict result
ok 21 - merge-recursive d/f conflict
ok 22 - merge-recursive d/f conflict result
ok 23 - reset and 3-way merge
ok 24 - reset and bind merge
ok 25 - merge removes empty directories
not ok 26 - merge-recursive simple w/submodule # TODO known breakage
not ok 27 - merge-recursive simple w/submodule result # TODO known breakage
# still have 2 known breakage(s)
# passed all remaining 25 test(s)
1..27
