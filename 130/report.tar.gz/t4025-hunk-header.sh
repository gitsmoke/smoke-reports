ok 1 - setup
ok 2 - hunk header truncation with an overly long line
# passed all 2 test(s)
1..2
