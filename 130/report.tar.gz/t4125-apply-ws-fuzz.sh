ok 1 - setup
ok 2 - nofix
ok 3 - withfix (forward)
ok 4 - withfix (backward)
# passed all 4 test(s)
1..4
