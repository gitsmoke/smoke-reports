ok 1 - setup
ok 2 - plain recursive - should conflict
ok 3 - recursive favouring theirs
ok 4 - recursive favouring ours
ok 5 - pull with -X
# passed all 5 test(s)
1..5
