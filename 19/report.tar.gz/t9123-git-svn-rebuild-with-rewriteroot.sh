ok 1 - init, fetch and checkout repository
ok 2 - remove rev_map
ok 3 - rebuild rev_map
# passed all 3 test(s)
1..3
