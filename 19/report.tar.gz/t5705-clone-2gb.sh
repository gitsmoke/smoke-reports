# passed all 0 test(s)
1..0 # SKIP Skipping expensive 2GB clone test; enable it with GIT_TEST_CLONE_2GB=t
