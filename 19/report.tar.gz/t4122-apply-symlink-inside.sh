ok 1 - setup
ok 2 - apply
ok 3 - check result
# passed all 3 test(s)
1..3
