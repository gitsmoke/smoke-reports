ok 1 - setup
ok 2 - push reports error
ok 3 - individual ref reports error
# passed all 3 test(s)
1..3
