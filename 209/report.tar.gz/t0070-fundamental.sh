ok 1 - character classes (isspace, isalpha etc.)
# passed all 1 test(s)
1..1
