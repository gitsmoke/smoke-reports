ok 1 - ls-files in empty repository
ok 2 - ls-files with nonexistent path
ok 3 - ls-files with nonsense option
ok 4 - ls-files -h in corrupt repository
# passed all 4 test(s)
1..4
