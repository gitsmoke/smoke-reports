ok 1 - setup first case
ok 2 - blame runs on unconflicted file while other file has conflicts
ok 3 - blame runs on conflicted file in stages 1,3
# passed all 3 test(s)
1..3
