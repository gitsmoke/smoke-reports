ok 1 - New file
ok 2 - Remove two files, add two and update two
ok 3 - Fail to change binary more than one generation old
ok 4 - Remove only binary files
ok 5 - Remove only a text file
ok 6 - New file with spaces in file name
ok 7 - Update file with spaces in file name
ok 8 - Mismatching patch should fail
ok 9 - Retain execute bit
ok 10 - -w option should work with relative GIT_DIR
ok 11 - check files before directories
ok 12 - re-commit a removed filename which remains in CVS attic
ok 13 - commit a file with leading spaces in the name
ok 14 - use the same checkout for Git and CVS
# passed all 14 test(s)
1..14
