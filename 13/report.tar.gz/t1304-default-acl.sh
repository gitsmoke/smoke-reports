# passed all 0 test(s)
1..0 # SKIP Skipping ACL tests: unable to use setfacl (output: 't1304-default-acl.sh: line 18: setfacl: command not found'; return code: '127')
