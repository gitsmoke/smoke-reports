ok 1 - prepare repository
ok 2 - move the files into a "sub" directory
ok 3 - git show -C -C report renames
# passed all 3 test(s)
1..3
