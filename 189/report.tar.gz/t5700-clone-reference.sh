ok 1 - preparing first repository
ok 2 - preparing second repository
ok 3 - cloning with reference (-l -s)
ok 4 - existence of info/alternates
ok 5 - pulling from reference
ok 6 - that reference gets used
ok 7 - cloning with reference (no -l -s)
ok 8 - fetched no objects
ok 9 - existence of info/alternates
ok 10 - pulling from reference
ok 11 - that reference gets used
ok 12 - updating origin
ok 13 - pulling changes from origin
ok 14 - that alternate to origin gets used
ok 15 - pulling changes from origin
ok 16 - check objects expected to exist locally
ok 17 - preparing alternate repository #1
ok 18 - cloning alternate repo #2 and adding changes to repo #1
ok 19 - cloning alternate repo #1, using #2 as reference
ok 20 - cloning with reference being subset of source (-l -s)
# passed all 20 test(s)
1..20
