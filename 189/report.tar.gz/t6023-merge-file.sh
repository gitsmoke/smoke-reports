ok 1 - merge with no changes
ok 2 - merge without conflict
ok 3 - merge without conflict (--quiet)
ok 4 - merge without conflict (missing LF at EOF)
ok 5 - merge result added missing LF
ok 6 - merge with conflicts
ok 7 - expected conflict markers
ok 8 - merge with conflicts, using -L
ok 9 - expected conflict markers, with -L
ok 10 - conflict in removed tail
ok 11 - expected conflict markers
ok 12 - binary files cannot be merged
ok 13 - MERGE_ZEALOUS simplifies non-conflicts
ok 14 - ZEALOUS_ALNUM
ok 15 - "diff3 -m" style output (1)
ok 16 - "diff3 -m" style output (2)
ok 17 - marker size
# passed all 17 test(s)
1..17
