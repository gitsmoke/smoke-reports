ok 1 - create commit with utf-8 body
ok 2 - patch has mime headers
ok 3 - patch has mime and extra headers
# passed all 3 test(s)
1..3
