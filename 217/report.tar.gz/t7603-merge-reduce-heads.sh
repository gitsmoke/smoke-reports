ok 1 - setup
ok 2 - merge c1 with c2, c3, c4, c5
ok 3 - setup
ok 4 - merge E and I
ok 5 - verify merge result
ok 6 - add conflicts
ok 7 - merge E2 and I2, causing a conflict and resolve it
ok 8 - verify merge result
# passed all 8 test(s)
1..8
