ok 1 - setup
ok 2 - reset --hard should restore unmerged ones
ok 3 - reset --hard did not corrupt index nor cached-tree
# passed all 3 test(s)
1..3
