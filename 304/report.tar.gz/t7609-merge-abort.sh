ok 1 - setup
ok 2 - fails without MERGE_HEAD (unstarted merge)
ok 3 - fails without MERGE_HEAD (completed merge)
ok 4 - Forget previous merge
ok 5 - Abort after --no-commit
ok 6 - Abort after conflicts
ok 7 - Clean merge with dirty index fails
ok 8 - Conflicting merge with dirty index fails
ok 9 - Reset index (but preserve worktree changes)
ok 10 - Abort clean merge with non-conflicting dirty worktree
ok 11 - Abort conflicting merge with non-conflicting dirty worktree
ok 12 - Reset worktree changes
ok 13 - Fail clean merge with conflicting dirty worktree
ok 14 - Fail conflicting merge with conflicting dirty worktree
ok 15 - Reset worktree changes
ok 16 - Fail clean merge with matching dirty worktree
ok 17 - Abort clean merge with matching dirty index
ok 18 - Reset worktree changes
ok 19 - Fail conflicting merge with matching dirty worktree
ok 20 - Abort conflicting merge with matching dirty index
ok 21 - Reset worktree changes
ok 22 - Abort merge with pre- and post-merge worktree changes
ok 23 - Reset worktree changes
ok 24 - Abort merge with pre- and post-merge index changes
# passed all 24 test(s)
1..24
