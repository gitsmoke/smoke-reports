ok 1 - setup
ok 2 - apply in forward
ok 3 - apply in reverse
ok 4 - setup separate repository lacking postimage
ok 5 - apply in forward without postimage
ok 6 - apply in reverse without postimage
ok 7 - reversing a whitespace introduction
# passed all 7 test(s)
1..7
