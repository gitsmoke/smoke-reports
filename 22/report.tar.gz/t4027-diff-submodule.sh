ok 1 - setup
ok 2 - git diff --raw HEAD
ok 3 - git diff-index --raw HEAD
ok 4 - git diff-files --raw
ok 5 - git diff HEAD
ok 6 - git diff HEAD with dirty submodule (work tree)
ok 7 - git diff HEAD with dirty submodule (index)
ok 8 - git diff HEAD with dirty submodule (untracked)
ok 9 - git diff HEAD with dirty submodule (work tree, refs match)
ok 10 - git diff HEAD with dirty submodule (index, refs match)
ok 11 - git diff HEAD with dirty submodule (untracked, refs match)
ok 12 - git diff (empty submodule dir)
ok 13 - conflicted submodule setup
ok 14 - combined (empty submodule)
ok 15 - combined (with submodule)
# passed all 15 test(s)
1..15
