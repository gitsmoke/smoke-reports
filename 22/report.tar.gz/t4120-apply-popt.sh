ok 1 - setup
ok 2 - apply git diff with -p2
ok 3 - apply with too large -p
# passed all 3 test(s)
1..3
