ok 1 - setup
ok 2 - interactive rebase --continue works with touched file
ok 3 - non-interactive rebase --continue works with touched file
# passed all 3 test(s)
1..3
