ok 1 - setup
ok 2 - "checkout -" does not work initially
ok 3 - first branch switch
ok 4 - "checkout -" switches back
ok 5 - "checkout -" switches forth
ok 6 - detach HEAD
ok 7 - "checkout -" attaches again
ok 8 - "checkout -" detaches again
ok 9 - more switches
ok 10 - switch to the last
ok 11 - switch to second from the last
ok 12 - switch to third from the last
ok 13 - switch to fourth from the last
ok 14 - switch to twelfth from the last
ok 15 - merge base test setup
ok 16 - another...master
ok 17 - ...master
ok 18 - master...
# passed all 18 test(s)
1..18
