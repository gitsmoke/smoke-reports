ok 1 - setup
ok 2 - pretty
ok 3 - pretty (tformat)
ok 4 - pretty (shortcut)
ok 5 - format
ok 6 - format %w(12,1,2)
ok 7 - format %w(,1,2)
ok 8 - oneline
ok 9 - diff-filter=A
ok 10 - diff-filter=M
ok 11 - diff-filter=D
ok 12 - diff-filter=R
ok 13 - diff-filter=C
ok 14 - git log --follow
ok 15 - git log --no-walk <commits> sorts by commit time
ok 16 - git show <commits> leaves list of commits as given
ok 17 - setup case sensitivity tests
ok 18 - log --grep
ok 19 - log -i --grep
ok 20 - log --grep -i
ok 21 - simple log --graph
ok 22 - set up merge history
ok 23 - log --graph with merge
ok 24 - log --graph with full output
ok 25 - set up more tangled history
ok 26 - log --graph with merge
ok 27 - log.decorate configuration
# passed all 27 test(s)
1..27
