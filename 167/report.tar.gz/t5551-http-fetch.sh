ok 1 - setup repository
ok 2 - create http-accessible bare repository
ok 3 - clone http repository
ok 4 - fetch changes via http
ok 5 - used upload-pack service
ok 6 - follow redirects (301)
ok 7 - follow redirects (302)
# passed all 7 test(s)
1..7
