ok 1 - setup
ok 2 - A/A conflict
ok 3 - Report path with conflict
ok 4 - Report new path with conflict
ok 5 - M/D conflict does not segfault
# passed all 5 test(s)
1..5
