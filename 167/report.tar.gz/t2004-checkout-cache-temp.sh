ok 1 - preparation
ok 2 - checkout one stage 0 to temporary file
ok 3 - checkout all stage 0 to temporary files
ok 4 - prepare 3-way merge
ok 5 - checkout one stage 2 to temporary file
ok 6 - checkout all stage 2 to temporary files
ok 7 - checkout all stages/one file to nothing
ok 8 - checkout all stages/one file to temporary files
ok 9 - checkout some stages/one file to temporary files
ok 10 - checkout all stages/all files to temporary files
ok 11 - -- path0: no entry
ok 12 - -- path1: all 3 stages
ok 13 - -- path2: no stage 1, have stage 2 and 3
ok 14 - -- path3: no stage 2, have stage 1 and 3
ok 15 - -- path4: no stage 3, have stage 1 and 3
ok 16 - -- asubdir/path5: no stage 2 and 3 have stage 1
ok 17 - checkout --temp within subdir
ok 18 - checkout --temp symlink
# passed all 18 test(s)
1..18
