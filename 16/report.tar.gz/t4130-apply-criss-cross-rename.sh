ok 1 - setup
ok 2 - criss-cross rename
ok 3 - diff -M -B
ok 4 - apply
ok 5 - criss-cross rename
ok 6 - diff -M -B
ok 7 - apply
# passed all 7 test(s)
1..7
