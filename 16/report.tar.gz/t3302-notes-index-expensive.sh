ok 1 - setup 10
ok 2 - notes work
not ok - 3 notes timing
#	time_notes 100
ok 1 - setup 100
ok 2 - notes work
not ok - 3 notes timing
#	time_notes 100
ok 1 - setup 1000
ok 2 - notes work
not ok - 3 notes timing
#	time_notes 100
ok 1 - setup 10000
ok 2 - notes work
not ok - 3 notes timing
#	time_notes 100
# passed all 0 test(s)
1..0
