ok 1 - setup
ok 2 - apply --whitespace=strip
ok 3 - apply --whitespace=strip from config
ok 4 - apply --whitespace=strip in subdir
ok 5 - apply --whitespace=strip from config in subdir
ok 6 - same in subdir but with traditional patch input
ok 7 - same but with traditional patch input of depth 1
ok 8 - same but with traditional patch input of depth 2
ok 9 - same but with traditional patch input of depth 1
ok 10 - same but with traditional patch input of depth 2
# passed all 10 test(s)
1..10
