ok 1 - import module
ok 2 - test branch master
ok 3 - test branch vendorbranch
not ok 4 - test branch B_FROM_INITIALS # TODO known breakage
not ok 5 - test branch B_FROM_INITIALS_BUT_ONE # TODO known breakage
not ok 6 - test branch B_MIXED # TODO known breakage
ok 7 - test branch B_SPLIT
not ok 8 - test tag vendortag # TODO known breakage
ok 9 - test tag T_ALL_INITIAL_FILES
not ok 10 - test tag T_ALL_INITIAL_FILES_BUT_ONE # TODO known breakage
not ok 11 - test tag T_MIXED # TODO known breakage
# still have 6 known breakage(s)
# passed all remaining 5 test(s)
1..11
