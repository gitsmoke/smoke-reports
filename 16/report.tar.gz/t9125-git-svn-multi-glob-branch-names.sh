ok 1 - setup svnrepo
ok 2 - test clone with multi-glob in branch names
ok 3 - test dcommit to multi-globbed branch
# passed all 3 test(s)
1..3
