ok 1 - setup: empty commit
ok 2 - setup: clean-up functions
ok 3 - setup: test prerequisites
ok 4 - plain, git-style file creation patch
ok 5 - plain, traditional patch
ok 6 - plain, traditional file creation patch
ok 7 - with spaces, git-style file creation patch
ok 8 - with spaces, traditional patch
ok 9 - with spaces, traditional file creation patch
ok 10 - with tab, git-style file creation patch
ok 11 - with tab, traditional patch
ok 12 - with tab, traditional file creation patch
ok 13 - with backslash, git-style file creation patch
ok 14 - with backslash, traditional patch
ok 15 - with backslash, traditional file creation patch
ok 16 - with quote, git-style file creation patch
not ok 17 - with quote, traditional patch # TODO known breakage
ok 18 - with quote, traditional file creation patch
ok 19 - whitespace-damaged traditional patch
# still have 1 known breakage(s)
# passed all remaining 18 test(s)
1..19
