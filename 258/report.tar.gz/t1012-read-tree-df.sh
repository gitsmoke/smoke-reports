ok 1 - setup
ok 2 - 3-way (1)
ok 3 - 3-way (2)
ok 4 - 3-way (3)
ok 5 - 2-way (1)
# passed all 5 test(s)
1..5
