ok 1 - setup
ok 2 - git diff --raw HEAD
ok 3 - git diff-index --raw HEAD
ok 4 - git diff-files --raw
ok 5 - git diff HEAD
ok 6 - git diff HEAD with dirty submodule (work tree)
ok 7 - git diff HEAD with dirty submodule (index)
ok 8 - git diff HEAD with dirty submodule (untracked)
ok 9 - git diff HEAD with dirty submodule (work tree, refs match)
ok 10 - git diff HEAD with dirty submodule (work tree, refs match) [.git/config]
ok 11 - git diff HEAD with dirty submodule (work tree, refs match) [.gitmodules]
ok 12 - git diff HEAD with dirty submodule (index, refs match)
ok 13 - git diff HEAD with dirty submodule (untracked, refs match)
ok 14 - git diff HEAD with dirty submodule (untracked, refs match) [.git/config]
ok 15 - git diff HEAD with dirty submodule (untracked, refs match) [.gitmodules]
ok 16 - git diff between submodule commits
ok 17 - git diff between submodule commits [.git/config]
ok 18 - git diff between submodule commits [.gitmodules]
ok 19 - git diff (empty submodule dir)
ok 20 - conflicted submodule setup
ok 21 - combined (empty submodule)
ok 22 - combined (with submodule)
# passed all 22 test(s)
1..22
