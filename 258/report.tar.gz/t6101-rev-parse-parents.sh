ok 1 - start is valid
ok 2 - start^0
ok 3 - start^1 not valid
ok 4 - second^1 = second^
ok 5 - final^1^1^1
ok 6 - final^1^1^1 = final^^^
ok 7 - final^1^2
ok 8 - final^1^2 != final^1^1
ok 9 - final^1^3 not valid
ok 10 - --verify start2^1
ok 11 - --verify start2^0
ok 12 - final^1^@ = final^1^1 final^1^2
ok 13 - final^1^! = final^1 ^final^1^1 ^final^1^2
ok 14 - repack for next test
ok 15 - short SHA-1 works
# passed all 15 test(s)
1..15
