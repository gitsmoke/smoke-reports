ok 1 - setup
ok 2 - same mode (no index)
ok 3 - same mode (with index)
ok 4 - same mode (index only)
ok 5 - mode update (no index)
ok 6 - mode update (with index)
ok 7 - mode update (index only)
# passed all 7 test(s)
1..7
