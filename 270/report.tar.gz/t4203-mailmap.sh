ok 1 - setup
ok 2 - No mailmap
ok 3 - default .mailmap
ok 4 - mailmap.file set
ok 5 - mailmap.file override
ok 6 - mailmap.file non-existant
ok 7 - name entry after email entry
ok 8 - name entry after email entry, case-insensitive
ok 9 - No mailmap files, but configured
ok 10 - Shortlog output (complex mapping)
ok 11 - Log output (complex mapping)
ok 12 - Blame output (complex mapping)
# passed all 12 test(s)
1..12
