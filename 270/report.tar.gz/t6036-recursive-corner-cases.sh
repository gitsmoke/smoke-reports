ok 1 - setup basic criss-cross + rename with no modifications
ok 2 - merge simple rename+criss-cross with no modifications
ok 3 - setup criss-cross + rename merges with basic modification
ok 4 - merge criss-cross + rename merges with basic modification
ok 5 - setup differently handled merges of rename/add conflict
ok 6 - git detects differently handled merges conflict
# passed all 6 test(s)
1..6
