ok 1 - setup svnrepo
ok 2 - import authors with prog and file
ok 3 - imported 6 revisions successfully
ok 4 - authors-prog ran correctly
ok 5 - authors-file overrode authors-prog
ok 6 - authors-prog handled special characters in username
# passed all 6 test(s)
1..6
