ok 1 - setup
ok 2 - switch from symlink to dir
ok 3 - Remove temporary directories & switch to master
ok 4 - switch from dir to symlink
# passed all 4 test(s)
1..4
