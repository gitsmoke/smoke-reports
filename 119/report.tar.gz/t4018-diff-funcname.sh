ok 1 - builtin bibtex pattern compiles
ok 2 - builtin bibtex wordRegex pattern compiles
ok 3 - builtin cpp pattern compiles
ok 4 - builtin cpp wordRegex pattern compiles
ok 5 - builtin csharp pattern compiles
ok 6 - builtin csharp wordRegex pattern compiles
ok 7 - builtin fortran pattern compiles
ok 8 - builtin fortran wordRegex pattern compiles
ok 9 - builtin html pattern compiles
ok 10 - builtin html wordRegex pattern compiles
ok 11 - builtin java pattern compiles
ok 12 - builtin java wordRegex pattern compiles
ok 13 - builtin objc pattern compiles
ok 14 - builtin objc wordRegex pattern compiles
ok 15 - builtin pascal pattern compiles
ok 16 - builtin pascal wordRegex pattern compiles
ok 17 - builtin php pattern compiles
ok 18 - builtin php wordRegex pattern compiles
ok 19 - builtin python pattern compiles
ok 20 - builtin python wordRegex pattern compiles
ok 21 - builtin ruby pattern compiles
ok 22 - builtin ruby wordRegex pattern compiles
ok 23 - builtin tex pattern compiles
ok 24 - builtin tex wordRegex pattern compiles
ok 25 - default behaviour
ok 26 - preset java pattern
ok 27 - custom pattern
ok 28 - last regexp must not be negated
ok 29 - pattern which matches to end of line
ok 30 - alternation in pattern
# passed all 30 test(s)
1..30
