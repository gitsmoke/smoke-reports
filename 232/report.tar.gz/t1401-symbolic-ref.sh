ok 1 - symbolic-ref writes HEAD
ok 2 - symbolic-ref reads HEAD
ok 3 - symbolic-ref refuses non-ref for HEAD
ok 4 - symbolic-ref refuses bare sha1
# passed all 4 test(s)
1..4
