ok 1 - setup
ok 2 - pack without --include-tag
ok 3 - unpack objects
ok 4 - check unpacked result (have commit, no tag)
ok 5 - pack with --include-tag
ok 6 - unpack objects
ok 7 - check unpacked result (have commit, have tag)
# passed all 7 test(s)
1..7
