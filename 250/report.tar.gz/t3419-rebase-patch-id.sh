ok 1 - setup
ok 2 - setup: 500 lines
ok 3 - setup attributes
ok 4 - detect upstream patch
ok 5 - do not drop patch
ok 6 # skip setup: 50000 lines (missing EXPENSIVE)
ok 7 # skip setup attributes (missing EXPENSIVE)
ok 8 # skip detect upstream patch (missing EXPENSIVE)
ok 9 # skip do not drop patch (missing EXPENSIVE)
# passed all 9 test(s)
1..9
