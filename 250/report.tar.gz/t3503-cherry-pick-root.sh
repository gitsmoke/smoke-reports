ok 1 - setup
ok 2 - cherry-pick a root commit
# passed all 2 test(s)
1..2
