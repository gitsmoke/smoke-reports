ok 1 - initialize repo
ok 2 - clone
ok 3 - empty directories exist
ok 4 - more emptiness
ok 5 - git svn rebase creates empty directory
ok 6 - git svn mkdirs recreates empty directories
ok 7 - git svn mkdirs -r works
ok 8 - initialize trunk
ok 9 - clone trunk
ok 10 - empty directories in trunk exist
ok 11 - remove a top-level directory from svn
ok 12 - removed top-level directory does not exist
ok 13 - git svn gc-ed files work
# passed all 13 test(s)
1..13
