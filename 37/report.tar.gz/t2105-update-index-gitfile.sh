ok 1 - submodule with absolute .git file
ok 2 - add gitlink to absolute .git file
ok 3 - submodule with relative .git file
ok 4 - add gitlink to relative .git file
# passed all 4 test(s)
1..4
