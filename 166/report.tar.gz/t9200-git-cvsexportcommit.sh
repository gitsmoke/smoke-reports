# passed all 0 test(s)
1..0 # SKIP skipping git cvsexportcommit tests, cvs not found
