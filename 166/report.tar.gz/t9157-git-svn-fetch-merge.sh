# passed all 0 test(s)
1..0 # SKIP Perl SVN libraries not found or unusable
