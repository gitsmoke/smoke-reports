filemode disabled on the filesystem
ok 1 - setup
ok 2 # skip same mode (no index) (missing FILEMODE of FILEMODE)
ok 3 # skip same mode (with index) (missing FILEMODE of FILEMODE)
ok 4 # skip same mode (index only) (missing FILEMODE of FILEMODE)
ok 5 # skip mode update (no index) (missing FILEMODE of FILEMODE)
ok 6 # skip mode update (with index) (missing FILEMODE of FILEMODE)
ok 7 # skip mode update (index only) (missing FILEMODE of FILEMODE)
# passed all 7 test(s)
1..7
