ok 1 # skip prepare reference tree (missing SYMLINKS of SYMLINKS)
ok 2 # skip prepare work tree (missing SYMLINKS of SYMLINKS)
ok 3 # skip setup diff output (missing SYMLINKS of SYMLINKS)
ok 4 # skip validate diff output (missing SYMLINKS of SYMLINKS)
# passed all 4 test(s)
1..4
