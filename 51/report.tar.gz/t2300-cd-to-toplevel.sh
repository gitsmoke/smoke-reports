ok 1 - at physical root
ok 2 - at physical subdir
ok 3 # skip at symbolic root (missing SYMLINKS of SYMLINKS)
ok 4 # skip at symbolic subdir (missing SYMLINKS of SYMLINKS)
ok 5 # skip at internal symbolic subdir (missing SYMLINKS of SYMLINKS)
# passed all 5 test(s)
1..5
