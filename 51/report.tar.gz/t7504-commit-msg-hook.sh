ok 1 - with no hook
ok 2 - with no hook (editor)
ok 3 - --no-verify with no hook
ok 4 - --no-verify with no hook (editor)
ok 5 - with succeeding hook
ok 6 - with succeeding hook (editor)
ok 7 - --no-verify with succeeding hook
ok 8 - --no-verify with succeeding hook (editor)
ok 9 - with failing hook
ok 10 - with failing hook (editor)
ok 11 - --no-verify with failing hook
ok 12 - --no-verify with failing hook (editor)
ok 13 # skip with non-executable hook (missing POSIXPERM of POSIXPERM)
ok 14 # skip with non-executable hook (editor) (missing POSIXPERM of POSIXPERM)
ok 15 # skip --no-verify with non-executable hook (missing POSIXPERM of POSIXPERM)
ok 16 # skip --no-verify with non-executable hook (editor) (missing POSIXPERM of POSIXPERM)
ok 17 - hook edits commit message
ok 18 - hook edits commit message (editor)
ok 19 - hook doesn't edit commit message
ok 20 - hook doesn't edit commit message (editor)
# passed all 20 test(s)
1..20
