ok 1 - with no hook
ok 2 - --no-verify with no hook
ok 3 - with succeeding hook
ok 4 - --no-verify with succeeding hook
ok 5 - with failing hook
ok 6 - --no-verify with failing hook
ok 7 # skip with non-executable hook (missing POSIXPERM of POSIXPERM)
ok 8 # skip --no-verify with non-executable hook (missing POSIXPERM of POSIXPERM)
# passed all 8 test(s)
1..8
