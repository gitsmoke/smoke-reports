ok 1 # skip Setup rename across paths each below D/F conflicts (missing SYMLINKS of SYMLINKS)
ok 2 # skip Cherry-pick succeeds with rename across D/F conflicts (missing SYMLINKS of SYMLINKS)
# passed all 2 test(s)
1..2
