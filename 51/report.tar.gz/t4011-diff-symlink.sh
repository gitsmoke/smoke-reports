ok 1 # skip diff new symlink (missing SYMLINKS of SYMLINKS)
ok 2 # skip diff unchanged symlink (missing SYMLINKS of SYMLINKS)
ok 3 # skip diff removed symlink (missing SYMLINKS of SYMLINKS)
ok 4 # skip diff identical, but newly created symlink (missing SYMLINKS of SYMLINKS)
ok 5 # skip diff different symlink (missing SYMLINKS of SYMLINKS)
ok 6 # skip diff symlinks with non-existing targets (missing SYMLINKS of SYMLINKS)
# passed all 6 test(s)
1..6
