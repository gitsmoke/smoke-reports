# passed all 0 test(s)
1..0 # SKIP skipping git svn tests, NO_SVN_TESTS defined
