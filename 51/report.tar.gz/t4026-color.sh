ok 1 - reset
ok 2 - attribute before color name
ok 3 - color name before attribute
ok 4 - attr fg bg
ok 5 - fg attr bg
ok 6 - fg bg attr
ok 7 - fg bg attr...
ok 8 - long color specification
ok 9 - 256 colors
ok 10 - color too small
ok 11 - color too big
ok 12 - extra character after color number
ok 13 - extra character after color name
ok 14 - extra character after attribute
ok 15 - unknown color slots are ignored (diff)
ok 16 - unknown color slots are ignored (branch)
ok 17 - unknown color slots are ignored (status)
# passed all 17 test(s)
1..17
