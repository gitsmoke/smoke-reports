ok 1 - prepare reference tree
ok 2 - prepare work tree
not ok - 3 validate output from rename/copy detection (#1)
#	compare_diff_patch current expected
ok 4 - prepare work tree again
not ok - 5 validate output from rename/copy detection (#2)
#	compare_diff_patch current expected
ok 6 - prepare work tree once again
not ok - 7 validate output from rename/copy detection (#3)
#	compare_diff_patch current expected
# failed 3 among 7 test(s)
1..7
