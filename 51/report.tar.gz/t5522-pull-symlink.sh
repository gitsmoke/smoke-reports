ok 1 # skip setup (missing SYMLINKS of SYMLINKS)
ok 2 # skip pulling from real subdir (missing SYMLINKS of SYMLINKS)
ok 3 # skip pulling from symlinked subdir (missing SYMLINKS of SYMLINKS)
ok 4 # skip pushing from symlinked subdir (missing SYMLINKS of SYMLINKS)
# passed all 4 test(s)
1..4
