ok 1 # skip setup (missing SYMLINKS of SYMLINKS)
ok 2 # skip apply symlink patch (missing SYMLINKS of SYMLINKS)
ok 3 # skip apply --index symlink patch (missing SYMLINKS of SYMLINKS)
# passed all 3 test(s)
1..3
