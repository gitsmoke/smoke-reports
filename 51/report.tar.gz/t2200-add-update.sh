ok 1 - setup
ok 2 - update
ok 3 - update noticed a removal
ok 4 - update touched correct path
ok 5 - update did not touch other tracked files
ok 6 - update did not touch untracked files
ok 7 - cache tree has not been corrupted
ok 8 - update from a subdirectory
ok 9 - change gets noticed
ok 10 # skip replace a file with a symlink (missing SYMLINKS of SYMLINKS)
ok 11 - add everything changed
ok 12 - touch and then add -u
ok 13 - touch and then add explicitly
ok 14 - add -n -u should not add but just report
ok 15 - add -u resolves unmerged paths
ok 16 - "add -u non-existent" should fail
# passed all 16 test(s)
1..16
