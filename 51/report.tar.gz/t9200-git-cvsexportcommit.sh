filemode disabled on the filesystem
FATAL: Unexpected exit with code 1
