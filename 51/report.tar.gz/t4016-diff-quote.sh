Your filesystem does not allow tabs in filenames
ok 1 # skip setup (missing TABS_IN_FILENAMES of TABS_IN_FILENAMES)
ok 2 # skip setup expected files (missing TABS_IN_FILENAMES of TABS_IN_FILENAMES)
ok 3 # skip git diff --summary -M HEAD (missing TABS_IN_FILENAMES of TABS_IN_FILENAMES)
ok 4 # skip setup expected files (missing TABS_IN_FILENAMES of TABS_IN_FILENAMES)
ok 5 # skip git diff --stat -M HEAD (missing TABS_IN_FILENAMES of TABS_IN_FILENAMES)
# passed all 5 test(s)
1..5
