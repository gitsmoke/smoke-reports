not ok - 1 apply diff between 0 and 1
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 2 apply diff between 0 and 2
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 3 apply diff between 0 and 3
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 4 apply diff between 1 and 0
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 5 apply diff between 1 and 2
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 6 apply diff between 1 and 3
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 7 apply diff between 2 and 0
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 8 apply diff between 2 and 1
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 9 apply diff between 2 and 3
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 10 apply diff between 3 and 0
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 11 apply diff between 3 and 1
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
not ok - 12 apply diff between 3 and 2
#	
#		git apply <"$TEST_DIRECTORY"/t4101/diff.$i-$j &&
#		test_cmp frotz.$j frotz
#	    
# failed 12 among 12 test(s)
1..12
