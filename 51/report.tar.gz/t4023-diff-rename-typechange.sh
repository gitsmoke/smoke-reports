ok 1 # skip setup (missing SYMLINKS of SYMLINKS)
ok 2 # skip cross renames to be detected for regular files (missing SYMLINKS of SYMLINKS)
ok 3 # skip cross renames to be detected for typechange (missing SYMLINKS of SYMLINKS)
ok 4 # skip moves and renames (missing SYMLINKS of SYMLINKS)
# passed all 4 test(s)
1..4
