ok 1 - setup
ok 2 - default
ok 3 - without -trail
ok 4 - without -trail (attribute)
ok 5 - without -space
ok 6 - without -space (attribute)
ok 7 - with indent-non-tab only
ok 8 - with indent-non-tab only (attribute)
ok 9 - with cr-at-eol
ok 10 - with cr-at-eol (attribute)
ok 11 - trailing empty lines (1)
ok 12 - trailing empty lines (2)
ok 13 - checkdiff shows correct line number for trailing blank lines
ok 14 - do not color trailing cr in context
ok 15 - color new trailing blank lines
# passed all 15 test(s)
1..15
