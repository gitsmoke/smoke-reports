ok 1 - setup
ok 2 - cherry-pick an empty commit
ok 3 - index lockfile was removed
ok 4 - cherry-pick a commit with an empty message
ok 5 - index lockfile was removed
# passed all 5 test(s)
1..5
