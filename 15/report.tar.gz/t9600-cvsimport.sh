ok 1 - setup cvsroot
ok 2 - setup a cvs module
ok 3 - import a trivial module
ok 4 - pack refs
ok 5 - initial import has correct .git/cvs-revisions
ok 6 - update cvs module
ok 7 - update git module
ok 8 - update has correct .git/cvs-revisions
ok 9 - update cvs module
ok 10 - cvsimport.module config works
ok 11 - second update has correct .git/cvs-revisions
ok 12 - import from a CVS working tree
ok 13 - no .git/cvs-revisions created by default
ok 14 - test entire HEAD
# passed all 14 test(s)
1..14
