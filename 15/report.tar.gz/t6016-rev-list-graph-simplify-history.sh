ok 1 - set up rev-list --graph test
ok 2 - --graph --all
ok 3 - --graph --simplify-by-decoration
ok 4 - --graph --simplify-by-decoration prune branch B
ok 5 - --graph --full-history -- bar.txt
ok 6 - --graph --full-history --simplify-merges -- bar.txt
ok 7 - --graph -- bar.txt
ok 8 - --graph --sparse -- bar.txt
ok 9 - --graph ^C4
ok 10 - --graph ^C3
ok 11 - --graph --boundary ^C3
# passed all 11 test(s)
1..11
