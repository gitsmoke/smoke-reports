ok 1 - load repository with strange names
ok 2 - init and fetch repository
ok 3 - create file in existing ugly and empty dir
ok 4 - rename ugly file
ok 5 - rename pretty file
ok 6 - rename pretty file into ugly one
ok 7 - add a file with plus signs
ok 8 - clone the repository to test rebase
ok 9 - make a commit to test rebase
ok 10 - git svn rebase works inside a fresh-cloned repository
# passed all 10 test(s)
1..10
