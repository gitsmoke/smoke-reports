ok 1 - setup repository
ok 2 - create http-accessible bare repository
ok 3 - clone http repository
ok 4 - fetch changes via http
ok 5 - used upload-pack service
# passed all 5 test(s)
1..5
