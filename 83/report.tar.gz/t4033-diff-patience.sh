ok 1 - patience diff
ok 2 - patience diff output is valid
ok 3 - completely different files
# passed all 3 test(s)
1..3
