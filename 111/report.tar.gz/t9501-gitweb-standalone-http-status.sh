ok 1 - setup
ok 2 - snapshots: tgz only default format enabled
ok 3 - snapshots: all enabled in default, use default disabled value
ok 4 - snapshots: zip explicitly disabled
ok 5 - snapshots: tgz explicitly enabled
ok 6 - snapshots: good tree-ish id
ok 7 - snapshots: bad tree-ish id
ok 8 - snapshots: bad tree-ish id (tagged object)
ok 9 - snapshots: good object id
ok 10 - snapshots: bad object id
ok 11 - load checking: load too high (default action)
# passed all 11 test(s)
1..11
