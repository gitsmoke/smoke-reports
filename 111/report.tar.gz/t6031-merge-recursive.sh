ok 1 - mode change in one branch: keep changed version
ok 2 - verify executable bit on file
ok 3 - mode change in both branches: expect conflict
ok 4 - verify executable bit on file
ok 5 - merging with triple rename across D/F conflict
# passed all 5 test(s)
1..5
