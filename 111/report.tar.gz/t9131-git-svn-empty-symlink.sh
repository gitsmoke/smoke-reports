ok 1 - load svn dumpfile
ok 2 - clone using git svn
ok 3 - enable broken symlink workaround
ok 4 - "bar" is an empty file
ok 5 - get "bar" => symlink fix from svn
ok 6 - "bar" becomes a symlink
ok 7 - clone using git svn
ok 8 - disable broken symlink workaround
ok 9 - "bar" is an empty file
ok 10 - get "bar" => symlink fix from svn
ok 11 - "bar" does not become a symlink
ok 12 - clone using git svn
ok 13 - "bar" is an empty file
ok 14 - get "bar" => symlink fix from svn
ok 15 - "bar" does not become a symlink
# passed all 15 test(s)
1..15
