ok 1 - setup
ok 2 - straight copy without -C
ok 3 - straight move without -C
ok 4 - straight copy with -C
ok 5 - straight move with -C
ok 6 - straight copy with -C -C
ok 7 - straight move with -C -C
ok 8 - append without -C
ok 9 - append with -C
ok 10 - append with -C -C
ok 11 - append with -C -C -C
ok 12 - blame wholesale copy
ok 13 - blame wholesale copy and more
ok 14 - blame path that used to be a directory
ok 15 - blame to a commit with no author name
ok 16 - blame -L with invalid start
ok 17 - blame -L with invalid end
ok 18 - indent of line numbers, nine lines
ok 19 - indent of line numbers, ten lines
# passed all 19 test(s)
1..19
