ok 1 - setup
ok 2 - rev-list D..M
ok 3 - rev-list --ancestry-path D..M
ok 4 - rev-list D..M -- M.t
ok 5 - rev-list --ancestry-patch D..M -- M.t
# passed all 5 test(s)
1..5
