ok 1 - setup
ok 2 - apply symlink patch
ok 3 - apply --index symlink patch
# passed all 3 test(s)
1..3
