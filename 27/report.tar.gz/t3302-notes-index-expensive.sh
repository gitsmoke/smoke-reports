ok 1 - setup / mkdir
ok 2 - setup 10
ok 3 - notes work
ok 4 - notes timing with /usr/bin/time
ok 5 - teardown / cd ..
ok 6 # skip setup / mkdir (missing EXPENSIVE of EXPENSIVE)
ok 7 # skip setup 100 (missing EXPENSIVE of EXPENSIVE)
ok 8 # skip notes work (missing EXPENSIVE of EXPENSIVE)
ok 9 # skip notes timing with /usr/bin/time (missing EXPENSIVE of USR_BIN_TIME,EXPENSIVE)
ok 10 # skip teardown / cd .. (missing EXPENSIVE of EXPENSIVE)
ok 11 # skip setup / mkdir (missing EXPENSIVE of EXPENSIVE)
ok 12 # skip setup 1000 (missing EXPENSIVE of EXPENSIVE)
ok 13 # skip notes work (missing EXPENSIVE of EXPENSIVE)
ok 14 # skip notes timing with /usr/bin/time (missing EXPENSIVE of USR_BIN_TIME,EXPENSIVE)
ok 15 # skip teardown / cd .. (missing EXPENSIVE of EXPENSIVE)
ok 16 # skip setup / mkdir (missing EXPENSIVE of EXPENSIVE)
ok 17 # skip setup 10000 (missing EXPENSIVE of EXPENSIVE)
ok 18 # skip notes work (missing EXPENSIVE of EXPENSIVE)
ok 19 # skip notes timing with /usr/bin/time (missing EXPENSIVE of USR_BIN_TIME,EXPENSIVE)
ok 20 # skip teardown / cd .. (missing EXPENSIVE of EXPENSIVE)
# passed all 20 test(s)
1..20
