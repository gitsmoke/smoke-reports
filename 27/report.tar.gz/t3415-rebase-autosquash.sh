ok 1 - setup
ok 2 - auto fixup (option)
ok 3 - auto fixup (config)
ok 4 - auto squash (option)
ok 5 - auto squash (config)
ok 6 - misspelled auto squash
# passed all 6 test(s)
1..6
