ok 1 - setup svnrepo
ok 2 - clone multiple branch and tag paths
ok 3 - Multiple branch or tag paths require -d
ok 4 - create new branches and tags
# passed all 4 test(s)
1..4
