ok 1 - setup
ok 2 - rev-list --objects heeds pathspecs
ok 3 - rev-list --objects with pathspecs and deeper paths
ok 4 - rev-list --objects with pathspecs and copied files
# passed all 4 test(s)
1..4
