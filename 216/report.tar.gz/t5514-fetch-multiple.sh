ok 1 - setup
ok 2 - git fetch --all
ok 3 - git fetch --all should continue if a remote has errors
ok 4 - git fetch --all does not allow non-option arguments
ok 5 - git fetch --multiple (but only one remote)
ok 6 - git fetch --multiple (two remotes)
ok 7 - git fetch --multiple (bad remote names)
ok 8 - git fetch --all (skipFetchAll)
ok 9 - git fetch --multiple (ignoring skipFetchAll)
# passed all 9 test(s)
1..9
