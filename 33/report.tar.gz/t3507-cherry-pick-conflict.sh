ok 1 - setup
ok 2 - failed cherry-pick does not advance HEAD
ok 3 - failed cherry-pick produces dirty index
ok 4 - failed cherry-pick registers participants in index
ok 5 - failed cherry-pick describes conflict in work tree
ok 6 - diff3 -m style
ok 7 - revert also handles conflicts sanely
ok 8 - revert conflict, diff3 -m style
# passed all 8 test(s)
1..8
