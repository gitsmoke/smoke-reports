ok 1 - compute merge-base (single)
ok 2 - compute merge-base (all)
ok 3 - compute merge-base with show-branch
ok 4 - compute merge-base (single)
ok 5 - compute merge-base (all)
ok 6 - merge-base for octopus-step (setup)
ok 7 - merge-base A B C
ok 8 - merge-base A B C using show-branch
ok 9 - criss-cross merge-base for octopus-step (setup)
ok 10 - merge-base B A^^ A^^2
# passed all 10 test(s)
1..10
