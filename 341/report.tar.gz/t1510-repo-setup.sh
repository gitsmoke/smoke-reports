ok 1 - #0: setup
ok 2 - #0: at root
ok 3 - #0: in subdir
ok 4 - #1: setup
ok 5 - #1: at root
ok 6 - #1: in subdir
ok 7 - #2: setup
ok 8 - #2: at root
ok 9 - #2: in subdir
ok 10 - #2: relative GIT_DIR at root
ok 11 - #2: relative GIT_DIR in subdir
ok 12 - #3: setup
ok 13 - #3: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 14 - #3: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 15 - #3: GIT_DIR, GIT_WORK_TREE=root at root
ok 16 - #3: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 17 - #3: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 18 - #3: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 19 - #3: GIT_DIR, GIT_WORKTREE=root in subdir
ok 20 - #3: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 21 - #3: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 22 - #3: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 23 - #3: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 24 - #3: GIT_DIR, GIT_WORK_TREE=wt at root
ok 25 - #3: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 26 - #3: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 27 - #3: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 28 - #3: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 29 - #3: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 30 - #3: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 31 - #3: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 32 - #3: GIT_DIR, GIT_WORK_TREE=.. at root
ok 33 - #3: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 34 - #3: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 35 - #3: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 36 - #3: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 37 - #4: setup
ok 38 - #4: at root
ok 39 - #4: in subdir
ok 40 - #5: setup
ok 41 - #5: at root
ok 42 - #5: in subdir
ok 43 - #6: setup
ok 44 - #6: GIT_DIR(rel), core.worktree=.. at root
ok 45 - #6: GIT_DIR(rel), core.worktree=..(rel) at root
ok 46 - #6: GIT_DIR, core.worktree=.. at root
ok 47 - #6: GIT_DIR, core.worktree=..(rel) at root
ok 48 - #6: GIT_DIR(rel), core.worktree=.. in subdir
ok 49 - #6: GIT_DIR(rel), core.worktree=..(rel) in subdir
ok 50 - #6: GIT_DIR, core.worktree=.. in subdir
ok 51 - #6: GIT_DIR, core.worktree=..(rel) in subdir
ok 52 - #6: GIT_DIR(rel), core.worktree=../wt at root
ok 53 - #6: GIT_DIR(rel), core.worktree=../wt(rel) at root
ok 54 - #6: GIT_DIR, core.worktree=../wt(rel) at root
ok 55 - #6: GIT_DIR, core.worktree=../wt at root
ok 56 - #6: GIT_DIR(rel), core.worktree=../wt in subdir
ok 57 - #6: GIT_DIR(rel), core.worktree=../wt(rel) in subdir
ok 58 - #6: GIT_DIR, core.worktree=../wt(rel) in subdir
ok 59 - #6: GIT_DIR, core.worktree=../wt in subdir
ok 60 - #6: GIT_DIR(rel), core.worktree=../.. at root
ok 61 - #6: GIT_DIR(rel), core.worktree=../..(rel) at root
ok 62 - #6: GIT_DIR, core.worktree=../..(rel) at root
ok 63 - #6: GIT_DIR, core.worktree=../.. at root
ok 64 - #6: GIT_DIR(rel), core.worktree=../.. in subdir
ok 65 - #6: GIT_DIR(rel), core.worktree=../..(rel) in subdir
ok 66 - #6: GIT_DIR, core.worktree=../..(rel) in subdir
ok 67 - #6: GIT_DIR, core.worktree=../.. in subdir
ok 68 - #7: setup
ok 69 - #7: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 70 - #7: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 71 - #7: GIT_DIR, GIT_WORK_TREE=root at root
ok 72 - #7: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 73 - #7: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 74 - #7: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 75 - #7: GIT_DIR, GIT_WORKTREE=root in subdir
ok 76 - #7: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 77 - #7: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 78 - #7: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 79 - #7: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 80 - #7: GIT_DIR, GIT_WORK_TREE=wt at root
ok 81 - #7: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 82 - #7: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 83 - #7: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 84 - #7: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 85 - #7: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 86 - #7: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 87 - #7: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 88 - #7: GIT_DIR, GIT_WORK_TREE=.. at root
ok 89 - #7: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 90 - #7: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 91 - #7: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 92 - #7: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 93 - #8: setup
ok 94 - #8: at root
ok 95 - #8: in subdir
ok 96 - #9: setup
ok 97 - #9: at root
ok 98 - #9: in subdir
ok 99 - #10: setup
ok 100 - #10: at root
ok 101 - #10: in subdir
ok 102 - #10: relative GIT_DIR at root
ok 103 - #10: relative GIT_DIR in subdir
ok 104 - #11: setup
ok 105 - #11: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 106 - #11: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 107 - #11: GIT_DIR, GIT_WORK_TREE=root at root
ok 108 - #11: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 109 - #11: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 110 - #11: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 111 - #11: GIT_DIR, GIT_WORKTREE=root in subdir
ok 112 - #11: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 113 - #11: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 114 - #11: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 115 - #11: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 116 - #11: GIT_DIR, GIT_WORK_TREE=wt at root
ok 117 - #11: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 118 - #11: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 119 - #11: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 120 - #11: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 121 - #11: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 122 - #11: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 123 - #11: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 124 - #11: GIT_DIR, GIT_WORK_TREE=.. at root
ok 125 - #11: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 126 - #11: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 127 - #11: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 128 - #11: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 129 - #12: setup
ok 130 - #12: at root
ok 131 - #12: in subdir
ok 132 - #13: setup
ok 133 - #13: at root
ok 134 - #13: in subdir
ok 135 - #14: setup
ok 136 - #14: GIT_DIR(rel), core.worktree=../14 at root
ok 137 - #14: GIT_DIR(rel), core.worktree=../14(rel) at root
ok 138 - #14: GIT_DIR, core.worktree=../14 at root
ok 139 - #14: GIT_DIR, core.worktree=../14(rel) at root
ok 140 - #14: GIT_DIR(rel), core.worktree=../14 in subdir
ok 141 - #14: GIT_DIR(rel), core.worktree=../14(rel) in subdir
ok 142 - #14: GIT_DIR, core.worktree=../14 in subdir
ok 143 - #14: GIT_DIR, core.worktree=../14(rel) in subdir
ok 144 - #14: GIT_DIR(rel), core.worktree=../14/wt at root
ok 145 - #14: GIT_DIR(rel), core.worktree=../14/wt(rel) at root
ok 146 - #14: GIT_DIR, core.worktree=../14/wt(rel) at root
ok 147 - #14: GIT_DIR, core.worktree=../14/wt at root
ok 148 - #14: GIT_DIR(rel), core.worktree=../14/wt in subdir
ok 149 - #14: GIT_DIR(rel), core.worktree=../14/wt(rel) in subdir
ok 150 - #14: GIT_DIR, core.worktree=../14/wt(rel) in subdir
ok 151 - #14: GIT_DIR, core.worktree=../14/wt in subdir
ok 152 - #14: GIT_DIR(rel), core.worktree=.. at root
ok 153 - #14: GIT_DIR(rel), core.worktree=..(rel) at root
ok 154 - #14: GIT_DIR, core.worktree=..(rel) at root
ok 155 - #14: GIT_DIR, core.worktree=.. at root
ok 156 - #14: GIT_DIR(rel), core.worktree=.. in subdir
ok 157 - #14: GIT_DIR(rel), core.worktree=..(rel) in subdir
ok 158 - #14: GIT_DIR, core.worktree=..(rel) in subdir
ok 159 - #14: GIT_DIR, core.worktree=.. in subdir
ok 160 - #15: setup
ok 161 - #15: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 162 - #15: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 163 - #15: GIT_DIR, GIT_WORK_TREE=root at root
ok 164 - #15: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 165 - #15: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 166 - #15: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 167 - #15: GIT_DIR, GIT_WORKTREE=root in subdir
ok 168 - #15: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 169 - #15: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 170 - #15: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 171 - #15: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 172 - #15: GIT_DIR, GIT_WORK_TREE=wt at root
ok 173 - #15: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 174 - #15: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 175 - #15: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 176 - #15: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 177 - #15: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 178 - #15: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 179 - #15: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 180 - #15: GIT_DIR, GIT_WORK_TREE=.. at root
ok 181 - #15: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 182 - #15: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 183 - #15: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 184 - #15: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 185 - #16.1: setup
ok 186 - #16.1: at .git
ok 187 - #16.1: in .git/wt
ok 188 - #16.1: in .git/wt/sub
ok 189 - #16.2: setup
ok 190 - #16.2: at .git
ok 191 - #16.2: in .git/wt
ok 192 - #16.2: in .git/wt/sub
ok 193 - #16.2: at root
ok 194 - #16.2: in subdir
ok 195 - #17.1: setup
ok 196 - #17.1: at .git
ok 197 - #17.1: in .git/wt
ok 198 - #17.1: in .git/wt/sub
ok 199 - #17.2: setup
ok 200 - #17.2: at .git
ok 201 - #17.2: in .git/wt
ok 202 - #17.2: in .git/wt/sub
ok 203 - #17.2: at root
ok 204 - #17.2: in subdir
ok 205 - #18: setup
ok 206 - #18: (rel) at root
ok 207 - #18: at root
ok 208 - #18: (rel) in subdir
ok 209 - #18: in subdir
ok 210 - #19: setup
ok 211 - #19: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 212 - #19: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 213 - #19: GIT_DIR, GIT_WORK_TREE=root at root
ok 214 - #19: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 215 - #19: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 216 - #19: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 217 - #19: GIT_DIR, GIT_WORKTREE=root in subdir
ok 218 - #19: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 219 - #19: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 220 - #19: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 221 - #19: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 222 - #19: GIT_DIR, GIT_WORK_TREE=wt at root
ok 223 - #19: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 224 - #19: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 225 - #19: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 226 - #19: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 227 - #19: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 228 - #19: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 229 - #19: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 230 - #19: GIT_DIR, GIT_WORK_TREE=.. at root
ok 231 - #19: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 232 - #19: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 233 - #19: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 234 - #19: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 235 - #20.1: setup
ok 236 - #20.1: at .git
ok 237 - #20.1: in .git/wt
ok 238 - #20.1: in .git/wt/sub
ok 239 - #20.2: setup
ok 240 - #20.2: at .git
ok 241 - #20.2: in .git/wt
ok 242 - #20.2: in .git/wt/sub
ok 243 - #20.2: at root
ok 244 - #20.2: in subdir
ok 245 - #21.1: setup
ok 246 - #21.1: at .git
ok 247 - #21.1: in .git/wt
ok 248 - #21.1: in .git/wt/sub
ok 249 - #21.2: setup
ok 250 - #21.2: at .git
ok 251 - #21.2: in .git/wt
ok 252 - #21.2: in .git/wt/sub
ok 253 - #21.2: at root
ok 254 - #21.2: in subdir
ok 255 - #22.1: setup
ok 256 - #22.1: GIT_DIR(rel), core.worktree=. at .git
ok 257 - #22.1: GIT_DIR(rel), core.worktree=.(rel) at .git
ok 258 - #22.1: GIT_DIR, core.worktree=. at .git
ok 259 - #22.1: GIT_DIR, core.worktree=.(rel) at root
ok 260 - #22.1: GIT_DIR(rel), core.worktree=. in .git/sub
ok 261 - #22.1: GIT_DIR(rel), core.worktree=.(rel) in .git/sub
ok 262 - #22.1: GIT_DIR, core.worktree=. in .git/sub
ok 263 - #22.1: GIT_DIR, core.worktree=.(rel) in .git/sub
ok 264 - #22.1: GIT_DIR(rel), core.worktree=wt at .git
ok 265 - #22.1: GIT_DIR(rel), core.worktree=wt(rel) at .git
ok 266 - #22.1: GIT_DIR, core.worktree=wt(rel) at .git
ok 267 - #22.1: GIT_DIR, core.worktree=wt at .git
ok 268 - #22.1: GIT_DIR(rel), core.worktree=wt in .git/sub
ok 269 - #22.1: GIT_DIR(rel), core.worktree=wt(rel) in .git/sub
ok 270 - #22.1: GIT_DIR, core.worktree=wt(rel) in .git/sub
ok 271 - #22.1: GIT_DIR, core.worktree=wt in .git/sub
ok 272 - #22.1: GIT_DIR(rel), core.worktree=.. at .git
ok 273 - #22.1: GIT_DIR(rel), core.worktree=..(rel) at .git
ok 274 - #22.1: GIT_DIR, core.worktree=..(rel) at .git
ok 275 - #22.1: GIT_DIR, core.worktree=.. at .git
ok 276 - #22.1: GIT_DIR(rel), core.worktree=.. in .git/sub
ok 277 - #22.1: GIT_DIR(rel), core.worktree=..(rel) in .git/sub
ok 278 - #22.1: GIT_DIR, core.worktree=..(rel) in .git/sub
ok 279 - #22.1: GIT_DIR, core.worktree=.. in .git/sub
ok 280 - #22.2: setup
ok 281 - #22.2: at .git
ok 282 - #22.2: at root
ok 283 - #23: setup
ok 284 - #23: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 285 - #23: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 286 - #23: GIT_DIR, GIT_WORK_TREE=root at root
ok 287 - #23: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 288 - #23: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 289 - #23: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 290 - #23: GIT_DIR, GIT_WORKTREE=root in subdir
ok 291 - #23: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 292 - #23: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 293 - #23: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 294 - #23: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 295 - #23: GIT_DIR, GIT_WORK_TREE=wt at root
ok 296 - #23: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 297 - #23: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 298 - #23: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 299 - #23: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 300 - #23: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 301 - #23: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 302 - #23: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 303 - #23: GIT_DIR, GIT_WORK_TREE=.. at root
ok 304 - #23: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 305 - #23: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 306 - #23: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 307 - #23: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 308 - #24: setup
ok 309 - #24: at root
ok 310 - #24: in subdir
ok 311 - #25: setup
ok 312 - #25: at root
ok 313 - #25: in subdir
ok 314 - #26: setup
ok 315 - #26: (rel) at root
ok 316 - #26: at root
ok 317 - #26: (rel) in subdir
ok 318 - #26: in subdir
ok 319 - #27: setup
ok 320 - #27: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 321 - #27: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 322 - #27: GIT_DIR, GIT_WORK_TREE=root at root
ok 323 - #27: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 324 - #27: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 325 - #27: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 326 - #27: GIT_DIR, GIT_WORKTREE=root in subdir
ok 327 - #27: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 328 - #27: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 329 - #27: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 330 - #27: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 331 - #27: GIT_DIR, GIT_WORK_TREE=wt at root
ok 332 - #27: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 333 - #27: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 334 - #27: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 335 - #27: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 336 - #27: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 337 - #27: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 338 - #27: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 339 - #27: GIT_DIR, GIT_WORK_TREE=.. at root
ok 340 - #27: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 341 - #27: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 342 - #27: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 343 - #27: GIT_DIR, GIT_WORK_TREE=.. in subdir
ok 344 - #28: setup
ok 345 - #28: at root
ok 346 - #28: in subdir
ok 347 - #29: setup
ok 348 - #29: at root
ok 349 - #29: in subdir
ok 350 - #30: setup
ok 351 - #30: at root
ok 352 - #31: setup
ok 353 - #31: GIT_DIR(rel), GIT_WORK_TREE=root at root
ok 354 - #31: GIT_DIR(rel), GIT_WORK_TREE=root(rel) at root
ok 355 - #31: GIT_DIR, GIT_WORK_TREE=root at root
ok 356 - #31: GIT_DIR, GIT_WORK_TREE=root(rel) at root
ok 357 - #31: GIT_DIR(rel), GIT_WORKTREE=root in subdir
ok 358 - #31: GIT_DIR(rel), GIT_WORKTREE=root(rel) in subdir
ok 359 - #31: GIT_DIR, GIT_WORKTREE=root in subdir
ok 360 - #31: GIT_DIR, GIT_WORKTREE=root(rel) in subdir
ok 361 - #31: GIT_DIR(rel), GIT_WORK_TREE=wt at root
ok 362 - #31: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) at root
ok 363 - #31: GIT_DIR, GIT_WORK_TREE=wt(rel) at root
ok 364 - #31: GIT_DIR, GIT_WORK_TREE=wt at root
ok 365 - #31: GIT_DIR(rel), GIT_WORK_TREE=wt in subdir
ok 366 - #31: GIT_DIR(rel), GIT_WORK_TREE=wt(rel) in subdir
ok 367 - #31: GIT_DIR, GIT_WORK_TREE=wt(rel) in subdir
ok 368 - #31: GIT_DIR, GIT_WORK_TREE=wt in subdir
ok 369 - #31: GIT_DIR(rel), GIT_WORK_TREE=.. at root
ok 370 - #31: GIT_DIR(rel), GIT_WORK_TREE=..(rel) at root
ok 371 - #31: GIT_DIR, GIT_WORK_TREE=..(rel) at root
ok 372 - #31: GIT_DIR, GIT_WORK_TREE=.. at root
ok 373 - #31: GIT_DIR(rel), GIT_WORK_TREE=.. in subdir
ok 374 - #31: GIT_DIR(rel), GIT_WORK_TREE=..(rel) in subdir
ok 375 - #31: GIT_DIR, GIT_WORK_TREE=..(rel) in subdir
ok 376 - #31: GIT_DIR, GIT_WORK_TREE=.. in subdir
# passed all 376 test(s)
1..376
