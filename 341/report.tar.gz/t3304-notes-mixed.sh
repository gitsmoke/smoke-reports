ok 1 - setup: create a couple of commits
ok 2 - create a notes tree with both notes and non-notes
ok 3 - verify contents of notes
ok 4 - verify contents of non-notes
ok 5 - git-notes preserves non-notes
ok 6 - verify contents of non-notes after git-notes
# passed all 6 test(s)
1..6
