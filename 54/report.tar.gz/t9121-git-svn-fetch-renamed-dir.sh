ok 1 - load repository with renamed directory
ok 2 - init and fetch repository
# passed all 2 test(s)
1..2
