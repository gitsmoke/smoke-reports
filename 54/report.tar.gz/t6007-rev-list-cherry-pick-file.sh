ok 1 - setup
ok 2 - --left-right
ok 3 - --count
ok 4 - --cherry-pick foo comes up empty
ok 5 - --cherry-pick bar does not come up empty
ok 6 - --cherry-pick with independent, but identical branches
ok 7 - --count --left-right
# passed all 7 test(s)
1..7
