ok 1 - setup and corrupt repository
ok 2 - fsck fails
ok 3 - upload-pack fails due to error in pack-objects packing
ok 4 - corrupt repo differently
ok 5 - fsck fails
ok 6 - upload-pack fails due to error in rev-list
ok 7 - upload-pack error message when bad ref requested
ok 8 - upload-pack fails due to error in pack-objects enumeration
ok 9 - create empty repository
ok 10 - fetch fails
# passed all 10 test(s)
1..10
