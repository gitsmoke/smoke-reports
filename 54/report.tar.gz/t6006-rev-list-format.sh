ok 1 - setup
ok 2 - format percent
ok 3 - format hash
ok 4 - format tree
ok 5 - format parents
ok 6 - format author
ok 7 - format committer
ok 8 - format encoding
ok 9 - format subject
ok 10 - format body
ok 11 - format raw-body
ok 12 - format colors
ok 13 - format advanced-colors
ok 14 - setup complex body
ok 15 - format complex-encoding
ok 16 - format complex-subject
ok 17 - format complex-body
ok 18 - %ad respects --date=
ok 19 - empty email
ok 20 - del LF before empty (1)
ok 21 - del LF before empty (2)
ok 22 - add LF before non-empty (1)
ok 23 - add LF before non-empty (2)
ok 24 - add SP before non-empty (1)
ok 25 - add SP before non-empty (2)
ok 26 - --abbrev
ok 27 - %H is not affected by --abbrev-commit
ok 28 - %h is not affected by --abbrev-commit
ok 29 - "%h %gD: %gs" is same as git-reflog
ok 30 - "%h %gD: %gs" is same as git-reflog (with date)
ok 31 - "%h %gD: %gs" is same as git-reflog (with --abbrev)
ok 32 - %gd shortens ref name
ok 33 - oneline with empty message
# passed all 33 test(s)
1..33
