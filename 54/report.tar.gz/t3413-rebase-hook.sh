ok 1 - setup
ok 2 - rebase
ok 3 - rebase -i
ok 4 - setup pre-rebase hook
ok 5 - pre-rebase hook gets correct input (1)
ok 6 - pre-rebase hook gets correct input (2)
ok 7 - pre-rebase hook gets correct input (3)
ok 8 - pre-rebase hook gets correct input (4)
ok 9 - pre-rebase hook gets correct input (5)
ok 10 - pre-rebase hook gets correct input (6)
ok 11 - setup pre-rebase hook that fails
ok 12 - pre-rebase hook stops rebase (1)
ok 13 - pre-rebase hook stops rebase (2)
ok 14 - rebase --no-verify overrides pre-rebase (1)
ok 15 - rebase --no-verify overrides pre-rebase (2)
# passed all 15 test(s)
1..15
