ok 1 - setup
ok 2 - saying "n" does nothing
ok 3 - git stash -p
ok 4 - git stash -p --no-keep-index
ok 5 - none of this moved HEAD
# passed all 5 test(s)
1..5
