ok 1 - setup
ok 2 - format normally
ok 3 - format with signoff without funny signer name
ok 4 - format with non ASCII signer name
ok 5 - attach and signoff do not duplicate mime headers
# passed all 5 test(s)
1..5
