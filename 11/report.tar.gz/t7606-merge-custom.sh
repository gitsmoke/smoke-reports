ok 1 - setup
ok 2 - merge c2 with a custom strategy
# passed all 2 test(s)
1..2
