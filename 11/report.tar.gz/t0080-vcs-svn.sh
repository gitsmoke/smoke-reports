ok 1 - obj pool: store data
ok 2 - obj pool: NULL is offset ~0
ok 3 - obj pool: out-of-bounds access
ok 4 - obj pool: high-water mark
ok 5 - treap sort
# passed all 5 test(s)
1..5
