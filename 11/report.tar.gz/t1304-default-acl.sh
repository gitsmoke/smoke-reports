# passed all 0 test(s)
1..0 # SKIP Skipping ACL tests: unable to use setfacl (output: 'File system doesn't support aclent_t style ACL's.
See acl(5) for more information on ACL styles support by Solaris.'; return code: '2')
