ok 1 - setup expect
ok 2 - git ls-files no-funny
ok 3 - setup expect
ok 4 - git ls-files with-funny
ok 5 - setup expect
ok 6 - git ls-files -z with-funny
ok 7 - setup expect
ok 8 - git ls-tree with funny
ok 9 - setup expect
ok 10 - git diff-index with-funny
ok 11 - git diff-tree with-funny
ok 12 - setup expect
ok 13 - git diff-index -z with-funny
ok 14 - git diff-tree -z with-funny
ok 15 - setup expect
ok 16 - git diff-tree -C with-funny
ok 17 - setup expect
ok 18 - git diff-tree delete with-funny
ok 19 - setup expect
ok 20 - git diff-tree delete with-funny
ok 21 - setup expect
ok 22 - git diff-tree delete with-funny
ok 23 - setup expect
ok 24 - git diff-tree rename with-funny applied
ok 25 - setup expect
ok 26 - git diff-tree delete with-funny applied
ok 27 - git apply non-git diff
# passed all 27 test(s)
1..27
