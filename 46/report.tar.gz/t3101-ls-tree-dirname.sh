ok 1 - setup
ok 2 - ls-tree plain
ok 3 - ls-tree recursive
ok 4 - ls-tree filter 1.txt
ok 5 - ls-tree filter path1/b/c/1.txt
ok 6 - ls-tree filter all 1.txt files
ok 7 - ls-tree filter directories
ok 8 - ls-tree filter odd names
ok 9 - ls-tree filter missing files and extra slashes
ok 10 - ls-tree filter is leading path match
ok 11 - ls-tree --full-name
ok 12 - ls-tree --full-tree
ok 13 - ls-tree --full-tree -r
ok 14 - ls-tree --abbrev=5
ok 15 - ls-tree --name-only
ok 16 - ls-tree --name-only -r
# passed all 16 test(s)
1..16
