ok 1 - setup repository
ok 2 - cloning from local repo
ok 3 - cloning from remote repo
ok 4 - create new commit on remote
ok 5 - pulling from local repo
ok 6 - pulling from remote remote
ok 7 - pushing to local repo
ok 8 - synch with changes from localclone
ok 9 - pushing remote local repo
# passed all 9 test(s)
1..9
