ok 1 - setup a submodule tree
ok 2 - test basic "submodule foreach" usage
ok 3 - setup nested submodules
ok 4 - use "submodule foreach" to checkout 2nd level submodule
ok 5 - use "foreach --recursive" to checkout all submodules
ok 6 - test messages from "foreach --recursive"
ok 7 - test "foreach --quiet --recursive"
ok 8 - use "update --recursive" to checkout all submodules
ok 9 - test "status --recursive"
ok 10 - use "git clone --recursive" to checkout all submodules
# passed all 10 test(s)
1..10
