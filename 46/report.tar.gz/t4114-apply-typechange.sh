ok 1 - setup repository and commits
ok 2 - file renamed from foo to foo/baz
ok 3 - file renamed from foo/baz to foo
ok 4 - directory becomes file
ok 5 - file becomes directory
ok 6 - file becomes symlink
ok 7 - symlink becomes file
ok 8 - binary file becomes symlink
ok 9 - symlink becomes binary file
ok 10 - symlink becomes directory
ok 11 - directory becomes symlink
# passed all 11 test(s)
1..11
