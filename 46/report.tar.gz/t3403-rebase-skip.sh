ok 1 - setup
ok 2 - rebase with git am -3 (default)
ok 3 - rebase --skip with am -3
ok 4 - rebase moves back to skip-reference
ok 5 - checkout skip-merge
ok 6 - rebase with --merge
ok 7 - rebase --skip with --merge
ok 8 - merge and reference trees equal
ok 9 - moved back to branch correctly
# passed all 9 test(s)
1..9
