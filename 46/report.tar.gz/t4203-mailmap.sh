ok 1 - setup
ok 2 - No mailmap
ok 3 - default .mailmap
ok 4 - mailmap.file set
ok 5 - mailmap.file override
ok 6 - mailmap.file non-existant
ok 7 - No mailmap files, but configured
ok 8 - Shortlog output (complex mapping)
ok 9 - Log output (complex mapping)
ok 10 - Blame output (complex mapping)
# passed all 10 test(s)
1..10
