ok 1 - prepare repository
ok 2 - Merge with d/f conflicts
ok 3 - F/D conflict
# passed all 3 test(s)
1..3
