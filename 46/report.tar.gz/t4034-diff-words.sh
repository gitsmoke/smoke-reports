ok 1 - setup
ok 2 - word diff with runs of whitespace
ok 3 - --word-diff=color
ok 4 - --color --word-diff=color
ok 5 - --word-diff=porcelain
ok 6 - --word-diff=plain
ok 7 - --word-diff=plain --no-color
ok 8 - --word-diff=plain --color
ok 9 - word diff without context
ok 10 - word diff with a regular expression
ok 11 - set a diff driver
ok 12 - option overrides .gitattributes
ok 13 - use regex supplied by driver
ok 14 - set diff.wordRegex option
ok 15 - command-line overrides config
ok 16 - command-line overrides config: --word-diff-regex
ok 17 - .gitattributes override config
ok 18 - remove diff driver regex
ok 19 - use configured regex
ok 20 - test parsing words for newline
ok 21 - test when words are only removed at the end
ok 22 - --word-diff=none
# passed all 22 test(s)
1..22
