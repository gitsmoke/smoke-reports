ok 1 - setup test repository with old layout
ok 2 - old layout continues to work
# passed all 2 test(s)
1..2
