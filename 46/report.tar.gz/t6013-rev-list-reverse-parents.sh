ok 1 - set up --reverse example
ok 2 - --reverse --parents --full-history combines correctly
ok 3 - --boundary does too
# passed all 3 test(s)
1..3
