ok 1 - initialize repo
ok 2 - (supposedly) non-conflicting change from SVN
ok 3 - some unrelated changes to git
ok 4 - change file but in unrelated area
ok 5 - attempt to dcommit with a dirty index
# passed all 5 test(s)
1..5
