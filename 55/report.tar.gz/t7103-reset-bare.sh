ok 1 - setup non-bare
ok 2 - "hard" reset requires a worktree
ok 3 - "merge" reset requires a worktree
ok 4 - "keep" reset requires a worktree
ok 5 - "mixed" reset is ok
ok 6 - "soft" reset is ok
ok 7 - hard reset works with GIT_WORK_TREE
ok 8 - setup bare
ok 9 - "hard" reset is not allowed in bare
ok 10 - "merge" reset is not allowed in bare
ok 11 - "keep" reset is not allowed in bare
ok 12 - "mixed" reset is not allowed in bare
ok 13 - "soft" reset is allowed in bare
# passed all 13 test(s)
1..13
