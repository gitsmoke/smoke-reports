ok 1 - setup
ok 2 - pretty
ok 3 - pretty (tformat)
ok 4 - pretty (shortcut)
ok 5 - format
ok 6 - format %w(12,1,2)
ok 7 - format %w(,1,2)
ok 8 - oneline
ok 9 - diff-filter=A
ok 10 - diff-filter=M
ok 11 - diff-filter=D
ok 12 - diff-filter=R
ok 13 - diff-filter=C
ok 14 - git log --follow
ok 15 - git log --no-walk <commits> sorts by commit time
ok 16 - git show <commits> leaves list of commits as given
ok 17 - setup case sensitivity tests
ok 18 - log --grep
ok 19 - log --grep option parsing
ok 20 - log -i --grep
ok 21 - log --grep -i
ok 22 - simple log --graph
ok 23 - set up merge history
ok 24 - log --graph with merge
ok 25 - log --graph with full output
ok 26 - set up more tangled history
ok 27 - log --graph with merge
ok 28 - log.decorate configuration
ok 29 - show added path under "--follow -M"
# passed all 29 test(s)
1..29
