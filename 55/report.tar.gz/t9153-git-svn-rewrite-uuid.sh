ok 1 - load svn repo
ok 2 - verify uuid
# passed all 2 test(s)
1..2
