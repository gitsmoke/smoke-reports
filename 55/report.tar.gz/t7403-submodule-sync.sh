ok 1 - setup
ok 2 - change submodule
ok 3 - change submodule url
ok 4 - "git submodule sync" should update submodule URLs
# passed all 4 test(s)
1..4
