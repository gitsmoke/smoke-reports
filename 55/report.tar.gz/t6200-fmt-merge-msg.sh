ok 1 - setup
ok 2 - message for merging local branch
ok 3 - message for merging external branch
ok 4 - [merge] summary/log configuration
ok 5 - configurable shortlog length: merge.log
ok 6 - configurable shortlog length: --log
ok 7 - fmt-merge-msg -m
ok 8 - setup: expected shortlog for two branches
ok 9 - shortlog for two branches
ok 10 - merge-msg -F
ok 11 - merge-msg -F in subdirectory
ok 12 - merge-msg with nothing to merge
ok 13 - merge-msg tag
ok 14 - merge-msg two tags
ok 15 - merge-msg tag and branch
ok 16 - merge-msg lots of commits
# passed all 16 test(s)
1..16
