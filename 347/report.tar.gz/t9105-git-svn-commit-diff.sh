ok 1 - initialize repo
ok 2 - test the commit-diff command
ok 3 - commit-diff to a sub-directory (with git svn config)
# passed all 3 test(s)
1..3
