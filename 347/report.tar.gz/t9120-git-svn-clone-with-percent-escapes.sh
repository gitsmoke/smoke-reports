ok 1 - setup svnrepo
ok 2 - test clone with percent escapes
ok 3 - svn checkout with percent escapes
ok 4 - svn checkout with space
ok 5 - test clone trunk with percent escapes and minimize-url
ok 6 - test clone trunk with percent escapes
ok 7 - test clone --stdlayout with percent escapes
ok 8 - test clone -s with unescaped space
# passed all 8 test(s)
1..8
