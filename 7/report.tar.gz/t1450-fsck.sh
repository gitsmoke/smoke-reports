ok 1 - setup
ok 2 - HEAD is part of refs
ok 3 - loose objects borrowed from alternate are not missing
ok 4 - valid objects appear valid
ok 5 - object with bad sha1
ok 6 - branch pointing to non-commit
ok 7 - email without @ is okay
ok 8 - email with embedded > is not okay
ok 9 - tag pointing to nonexistent
ok 10 - tag pointing to something else than its type
# passed all 10 test(s)
1..10
