ok 1 - setup the repository
ok 2 - blame respects i18n.commitencoding
ok 3 - blame respects i18n.logoutputencoding
ok 4 - blame respects --encoding=UTF-8
ok 5 - blame respects --encoding=none
# passed all 5 test(s)
1..5
