ok 1 - builtin bibtex pattern compiles
ok 2 - builtin cpp pattern compiles
ok 3 - builtin csharp pattern compiles
ok 4 - builtin html pattern compiles
ok 5 - builtin java pattern compiles
ok 6 - builtin objc pattern compiles
ok 7 - builtin pascal pattern compiles
ok 8 - builtin php pattern compiles
ok 9 - builtin python pattern compiles
ok 10 - builtin ruby pattern compiles
ok 11 - builtin tex pattern compiles
ok 12 - default behaviour
ok 13 - preset java pattern
ok 14 - custom pattern
ok 15 - last regexp must not be negated
ok 16 - pattern which matches to end of line
ok 17 - alternation in pattern
# passed all 17 test(s)
1..17
