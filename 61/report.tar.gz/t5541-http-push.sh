ok 1 - setup remote repository
ok 2 - no empty path components
ok 3 - clone remote repository
ok 4 - push to remote repository
ok 5 - push already up-to-date
ok 6 - create and delete remote branch
ok 7 - used receive-pack service
ok 8 - non-fast-forward push fails
ok 9 - non-fast-forward push show ref status
ok 10 - non-fast-forward push shows help message
ok 11 - push fails for non-fast-forward refs unmatched by remote helper
# passed all 11 test(s)
1..11
