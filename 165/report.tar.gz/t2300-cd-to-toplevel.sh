ok 1 - at physical root
ok 2 - at physical subdir
ok 3 - at symbolic root
ok 4 - at symbolic subdir
ok 5 - at internal symbolic subdir
# passed all 5 test(s)
1..5
