ok 1 - setup
ok 2 - chmod
ok 3 - verify
# passed all 3 test(s)
1..3
