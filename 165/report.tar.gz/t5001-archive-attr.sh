ok 1 - setup
ok 2 - git archive
ok 3 -  archive/ignored does not exist
ok 4 -  archive/ignored-by-tree does not exist
ok 5 -  archive/ignored-by-worktree exists
ok 6 - git archive with worktree attributes
ok 7 -  worktree/ignored does not exist
ok 8 -  worktree/ignored-by-tree exists
ok 9 -  worktree/ignored-by-worktree does not exist
ok 10 - git archive vs. bare
ok 11 - git archive with worktree attributes, bare
ok 12 -  bare-worktree/ignored does not exist
ok 13 -  bare-worktree/ignored-by-tree exists
ok 14 -  bare-worktree/ignored-by-worktree exists
ok 15 - export-subst
ok 16 - git tar-tree vs. git archive with worktree attributes
ok 17 - git tar-tree vs. git archive with worktree attrs, bare
# passed all 17 test(s)
1..17
