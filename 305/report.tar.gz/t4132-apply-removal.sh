ok 1 - setup
ok 2 - test addEast.patch
ok 3 - test addGMT.patch
ok 4 - test addWest.patch
ok 5 - test createEast.patch
ok 6 - test createGMT.patch
ok 7 - test createWest.patch
ok 8 - test emptyEast.patch
ok 9 - test emptyGMT.patch
ok 10 - test emptyWest.patch
ok 11 - test removeEast.patch
ok 12 - test removeGMT.patch
ok 13 - test removeWest.patch
ok 14 - test removeWest2.patch
# passed all 14 test(s)
1..14
