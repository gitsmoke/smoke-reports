ok 1 - setup
ok 2 - example 1: notes to add an Acked-by line
ok 3 - example 2: binary notes
# passed all 3 test(s)
1..3
