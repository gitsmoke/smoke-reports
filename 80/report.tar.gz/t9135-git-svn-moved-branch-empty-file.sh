ok 1 - load svn dumpfile
ok 2 - clone using git svn
ok 3 - test that b1 exists and is empty
# passed all 3 test(s)
1..3
