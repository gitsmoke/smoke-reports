ok 1 - setup
ok 2 - merge c1 with c2
ok 3 - merge c1 with c2 (ours in pull.twohead)
ok 4 - merge c1 with c2 and c3 (recursive in pull.octopus)
ok 5 - merge c1 with c2 and c3 (recursive and octopus in pull.octopus)
ok 6 - setup conflicted merge
ok 7 - merge picks up the best result
ok 8 - merge picks up the best result (from config)
ok 9 - merge errors out on invalid strategy
ok 10 - merge errors out on invalid strategy
# passed all 10 test(s)
1..10
