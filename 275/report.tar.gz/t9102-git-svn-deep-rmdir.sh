ok 1 - initialize repo
ok 2 - mirror via git svn
ok 3 - Try a commit on rmdir
# passed all 3 test(s)
1..3
