ok 1 - setup remote repository
ok 2 - clone remote repository
ok 3 - push to remote repository with packed refs
ok 4 - push already up-to-date
ok 5 - push to remote repository with unpacked refs
ok 6 - http-push fetches unpacked objects
ok 7 - http-push fetches packed objects
ok 8 - create and delete remote branch
ok 9 - MKCOL sends directory names with trailing slashes
ok 10 - PUT and MOVE sends object to URLs with SHA-1 hash suffix
ok 11 - non-fast-forward push fails
ok 12 - non-fast-forward push show ref status
ok 13 - non-fast-forward push shows help message
# passed all 13 test(s)
1..13
