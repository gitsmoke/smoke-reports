ok 1 - gitdir selection on normal repos
ok 2 - gitdir selection on unsupported repo
ok 3 - gitdir not required mode
ok 4 - gitdir required mode on normal repos
ok 5 - gitdir required mode on unsupported repo
# passed all 5 test(s)
1..5
