ok 1 - diff new symlink
ok 2 - diff unchanged symlink
ok 3 - diff removed symlink
ok 4 - diff identical, but newly created symlink
ok 5 - diff different symlink
ok 6 - diff symlinks with non-existing targets
# passed all 6 test(s)
1..6
