ok 1 - setup
ok 2 - cherry-pick first..fourth works
ok 3 - cherry-pick --ff first..fourth works
ok 4 - cherry-pick -n first..fourth works
ok 5 - revert first..fourth works
ok 6 - revert ^first fourth works
ok 7 - revert fourth fourth~1 fourth~2 works
ok 8 - cherry-pick -3 fourth works
ok 9 - cherry-pick --stdin works
# passed all 9 test(s)
1..9
