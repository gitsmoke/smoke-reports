ok 1 - setup (initial)
ok 2 - status works (initial)
ok 3 - diff works (initial)
ok 4 - revert works (initial)
ok 5 - setup (commit)
ok 6 - status works (commit)
ok 7 - diff works (commit)
ok 8 - revert works (commit)
ok 9 - dummy edit works
ok 10 - bad edit rejected
ok 11 - garbage edit rejected
ok 12 - real edit works
ok 13 - skip files similarly as commit -a
ok 14 - patch does not affect mode
ok 15 - stage mode but not hunk
ok 16 - stage mode and hunk
ok 17 - setup again
ok 18 - add first line works
ok 19 - deleting a non-empty file
ok 20 - deleting an empty file
# passed all 20 test(s)
1..20
