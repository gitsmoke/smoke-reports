ok 1 - Setup test repo
ok 2 - Objects creation does not break ACLs with restrictive umask
ok 3 - git gc does not break ACLs with restrictive umask
# passed all 3 test(s)
1..3
