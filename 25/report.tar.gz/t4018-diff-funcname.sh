ok 1 - builtin bibtex pattern compiles
ok 2 - builtin cpp pattern compiles
ok 3 - builtin html pattern compiles
ok 4 - builtin java pattern compiles
ok 5 - builtin objc pattern compiles
ok 6 - builtin pascal pattern compiles
ok 7 - builtin php pattern compiles
ok 8 - builtin python pattern compiles
ok 9 - builtin ruby pattern compiles
ok 10 - builtin tex pattern compiles
ok 11 - default behaviour
ok 12 - preset java pattern
ok 13 - custom pattern
ok 14 - last regexp must not be negated
ok 15 - pattern which matches to end of line
ok 16 - alternation in pattern
# passed all 16 test(s)
1..16
