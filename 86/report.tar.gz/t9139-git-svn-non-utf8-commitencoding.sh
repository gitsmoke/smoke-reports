ok 1 - ISO8859-1 setup
ok 2 - eucJP setup
ok 3 - ISO8859-1 commit on git side
ok 4 - eucJP commit on git side
ok 5 - ISO8859-1 dcommit to svn
ok 6 - eucJP dcommit to svn
# passed all 6 test(s)
1..6
