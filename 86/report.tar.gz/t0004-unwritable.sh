ok 1 - setup
ok 2 - write-tree should notice unwritable repository
ok 3 - commit should notice unwritable repository
ok 4 - update-index should notice unwritable repository
ok 5 - add should notice unwritable repository
# passed all 5 test(s)
1..5
