ok 1 - setup
ok 2 - cvs co (default crlf)
ok 3 - cvs co (allbinary)
ok 4 - cvs co (use attributes/allbinary)
ok 5 - cvs co (use attributes)
ok 6 - adding files
ok 7 - updating
ok 8 - cvs co (use attributes/guess)
ok 9 - setup multi-line files
ok 10 - cvs co (guess)
ok 11 - cvs co another copy (guess)
ok 12 - add text (guess)
ok 13 - add bin (guess)
ok 14 - remove files (guess)
ok 15 - cvs ci (guess)
ok 16 - update subdir of other copy (guess)
ok 17 - update/merge full other copy (guess)
# passed all 17 test(s)
1..17
