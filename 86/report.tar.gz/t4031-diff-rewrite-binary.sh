ok 1 - create binary file with changes
ok 2 - vanilla diff is binary
ok 3 - rewrite diff is binary
ok 4 - rewrite diff can show binary patch
ok 5 - setup textconv
ok 6 - rewrite diff respects textconv
# passed all 6 test(s)
1..6
