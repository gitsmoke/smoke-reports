ok 1 - start tracking an empty repo
ok 2 - create files in new directory with dcommit
# passed all 2 test(s)
1..2
