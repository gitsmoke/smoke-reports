ok 1 - -A with -d option leaves unreachable objects unpacked
ok 2 - -A without -d option leaves unreachable objects packed
ok 3 - unpacked objects receive timestamp of pack file
# passed all 3 test(s)
1..3
