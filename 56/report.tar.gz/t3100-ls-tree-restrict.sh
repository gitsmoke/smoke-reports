ok 1 - setup
ok 2 - ls-tree plain
ok 3 - ls-tree recursive
ok 4 - ls-tree recursive with -t
ok 5 - ls-tree recursive with -d
ok 6 - ls-tree filtered with path
ok 7 - ls-tree filtered with path1 path0
ok 8 - ls-tree filtered with path0/
ok 9 - ls-tree filtered with path2
ok 10 - ls-tree filtered with path2/
ok 11 - ls-tree filtered with path2/baz
ok 12 - ls-tree filtered with path2/bak
ok 13 - ls-tree -t filtered with path2/bak
# passed all 13 test(s)
1..13
