ok 1 - load svn dumpfile
ok 2 - clone using git svn
ok 3 - "bar" is a symlink that points to "asdf"
ok 4 - get "bar" => symlink fix from svn
ok 5 - "bar" remains a proper symlink
# passed all 5 test(s)
1..5
