ok 1 - setup test repository
ok 2 - clone trunk with "-r HEAD"
# passed all 2 test(s)
1..2
