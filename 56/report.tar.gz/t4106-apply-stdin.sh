ok 1 - setup
ok 2 - git apply --numstat - < patch
ok 3 - git apply --numstat - < patch patch
# passed all 3 test(s)
1..3
