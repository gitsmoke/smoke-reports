ok 1 - added submodule
ok 2 - modified submodule(forward)
ok 3 - modified submodule(forward)
ok 4 - modified submodule(forward) --submodule
ok 5 - modified submodule(forward) --submodule=short
ok 6 - modified submodule(backward)
ok 7 - modified submodule(backward and forward)
ok 8 - typechanged submodule(submodule->blob), --cached
ok 9 - typechanged submodule(submodule->blob)
ok 10 - typechanged submodule(submodule->blob)
ok 11 - nonexistent commit
ok 12 - typechanged submodule(blob->submodule)
ok 13 - submodule is up to date
ok 14 - submodule contains untracked content
ok 15 - submodule contains untracked content (untracked ignored)
ok 16 - submodule contains untracked content (dirty ignored)
ok 17 - submodule contains untracked content (all ignored)
ok 18 - submodule contains untracked and modifed content
ok 19 - submodule contains untracked and modifed content (untracked ignored)
ok 20 - submodule contains untracked and modifed content (dirty ignored)
ok 21 - submodule contains untracked and modifed content (all ignored)
ok 22 - submodule contains modifed content
ok 23 - submodule is modified
ok 24 - modified submodule contains untracked content
ok 25 - modified submodule contains untracked content (untracked ignored)
ok 26 - modified submodule contains untracked content (dirty ignored)
ok 27 - modified submodule contains untracked content (all ignored)
ok 28 - modified submodule contains untracked and modifed content
ok 29 - modified submodule contains untracked and modifed content (untracked ignored)
ok 30 - modified submodule contains untracked and modifed content (dirty ignored)
ok 31 - modified submodule contains untracked and modifed content (all ignored)
ok 32 - modified submodule contains modifed content
ok 33 - deleted submodule
ok 34 - multiple submodules
ok 35 - path filter
ok 36 - given commit
ok 37 - given commit --submodule
ok 38 - given commit --submodule=short
ok 39 - setup .git file for sm2
ok 40 - diff --submodule with .git file
# passed all 40 test(s)
1..40
