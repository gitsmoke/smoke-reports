ok 1 - setup
ok 2 - rewrite identically
ok 3 - result is really identical
ok 4 - rewrite bare repository identically
ok 5 - result is really identical
ok 6 - correct GIT_DIR while using -d
ok 7 - Fail if commit filter fails
ok 8 - rewrite, renaming a specific file
ok 9 - test that the file was renamed
ok 10 - rewrite, renaming a specific directory
ok 11 - test that the directory was renamed
ok 12 - rewrite one branch, keeping a side branch
ok 13 - common ancestor is still common (unchanged)
ok 14 - filter subdirectory only
ok 15 - subdirectory filter result looks okay
ok 16 - more setup
ok 17 - use index-filter to move into a subdirectory
ok 18 - stops when msg filter fails
ok 19 - author information is preserved
ok 20 - remove a certain author's commits
ok 21 - barf on invalid name
ok 22 - "map" works in commit filter
ok 23 - Name needing quotes
ok 24 - Subdirectory filter with disappearing trees
ok 25 - Tag name filtering retains tag message
ok 26 - Tag name filtering strips gpg signature
ok 27 - Tag name filtering allows slashes in tag names
ok 28 - Prune empty commits
ok 29 - --remap-to-ancestor with filename filters
ok 30 - automatic remapping to ancestor with filename filters
ok 31 - setup submodule
ok 32 - rewrite submodule with another content
ok 33 - replace submodule revision
# passed all 33 test(s)
1..33
