ok 1 - setup
ok 2 - showing a tag that point at a missing object
# passed all 2 test(s)
1..2
