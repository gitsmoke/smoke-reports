ok 1 - load svnsync repo
ok 2 - verify metadata for /bar
ok 3 - verify metadata for /dir/a/b/c/d/e
ok 4 - verify metadata for /dir
# passed all 4 test(s)
1..4
