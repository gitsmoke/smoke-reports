ok 1 - setup
ok 2 - branch --contains=master
ok 3 - branch --contains master
ok 4 - branch --contains=side
ok 5 - side: branch --merged
ok 6 - side: branch --no-merged
ok 7 - master: branch --merged
ok 8 - master: branch --no-merged
# passed all 8 test(s)
1..8
