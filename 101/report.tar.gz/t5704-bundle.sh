ok 1 - setup
ok 2 - tags can be excluded by rev-list options
ok 3 - die if bundle file cannot be created
not ok 4 - bundle --stdin # TODO known breakage
not ok 5 - bundle --stdin <rev-list options> # TODO known breakage
# still have 2 known breakage(s)
# passed all remaining 3 test(s)
1..5
