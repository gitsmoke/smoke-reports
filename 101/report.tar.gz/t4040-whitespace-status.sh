ok 1 - setup
ok 2 - diff-tree --exit-code
ok 3 - diff-tree -b --exit-code
ok 4 - diff-index --cached --exit-code
ok 5 - diff-index -b -p --cached --exit-code
ok 6 - diff-index --exit-code
ok 7 - diff-index -b -p --exit-code
ok 8 - diff-files --exit-code
ok 9 - diff-files -b -p --exit-code
# passed all 9 test(s)
1..9
