Unable to use setfacl (output: 'setfacl: /dev/shm/trash directory.t1304-default-acl: Operation not supported'; return code: '1')
ok 1 # skip Setup test repo (missing SETFACL)
ok 2 # skip Objects creation does not break ACLs with restrictive umask (missing SETFACL)
ok 3 # skip git gc does not break ACLs with restrictive umask (missing SETFACL)
# passed all 3 test(s)
1..3
