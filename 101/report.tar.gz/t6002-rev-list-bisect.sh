ok 1 - bisection diff --bisect l0 ^root <= 0
ok 2 - bisection diff --bisect l1 ^root <= 0
ok 3 - bisection diff --bisect l2 ^root <= 0
ok 4 - bisection diff --bisect a0 ^root <= 0
ok 5 - bisection diff --bisect a1 ^root <= 0
ok 6 - bisection diff --bisect a2 ^root <= 0
ok 7 - bisection diff --bisect a3 ^root <= 0
ok 8 - bisection diff --bisect b1 ^root <= 0
ok 9 - bisection diff --bisect b2 ^root <= 0
ok 10 - bisection diff --bisect b3 ^root <= 0
ok 11 - bisection diff --bisect c1 ^root <= 0
ok 12 - bisection diff --bisect c2 ^root <= 0
ok 13 - bisection diff --bisect c3 ^root <= 0
ok 14 - bisection diff --bisect E ^F <= 0
ok 15 - bisection diff --bisect e1 ^F <= 0
ok 16 - bisection diff --bisect e2 ^F <= 0
ok 17 - bisection diff --bisect e3 ^F <= 0
ok 18 - bisection diff --bisect e4 ^F <= 0
ok 19 - bisection diff --bisect e5 ^F <= 0
ok 20 - bisection diff --bisect e6 ^F <= 0
ok 21 - bisection diff --bisect e7 ^F <= 0
ok 22 - bisection diff --bisect f1 ^F <= 0
ok 23 - bisection diff --bisect f2 ^F <= 0
ok 24 - bisection diff --bisect f3 ^F <= 0
ok 25 - bisection diff --bisect f4 ^F <= 0
ok 26 - bisection diff --bisect E ^F <= 0
ok 27 - bisection diff --bisect V ^U <= 1
ok 28 - bisection diff --bisect V ^U ^u1 ^u2 ^u3 <= 0
ok 29 - bisection diff --bisect u1 ^U <= 0
ok 30 - bisection diff --bisect u2 ^U <= 0
ok 31 - bisection diff --bisect u3 ^U <= 0
ok 32 - bisection diff --bisect u4 ^U <= 0
ok 33 - bisection diff --bisect u5 ^U <= 0
ok 34 - --bisect l5 ^root
ok 35 - --bisect l5 ^root ^c3
ok 36 - --bisect l5 ^root ^c3 ^b4
ok 37 - --bisect l3 ^root ^c3 ^b4
ok 38 - --bisect l5 ^b3 ^a3 ^b4 ^a4
ok 39 - --bisect l4 ^a2 ^a3 ^b ^a4
ok 40 - --bisect l3 ^a2 ^a3 ^b ^a4
ok 41 - --bisect a4 ^a2 ^a3 ^b4
ok 42 - --bisect a4 ^a2 ^a3 ^b4 ^c2
ok 43 - --bisect a4 ^a2 ^a3 ^b4 ^c2 ^c3
ok 44 - --bisect a4 ^a2 ^a3 ^b4
ok 45 - --bisect c3 ^a2 ^a3 ^b4 ^c2
# passed all 45 test(s)
1..45
