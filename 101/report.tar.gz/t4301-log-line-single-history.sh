ok 1 - add path0/path1 and commit.
ok 2 - Change the 2,3 lines of path0 and path1.
ok 3 - Change the 5th line of path0.
ok 4 - Final change of path0.
ok 5 - Show the line level log of path0
ok 6 - validate the path0 output.
ok 7 - Show the line level log of path1
ok 8 - validate the path1 output.
ok 9 - Show the line level log of two files
ok 10 - validate the all path output.
ok 11 - Test the line number argument
ok 12 - validate the line number output.
ok 13 - Test the --full-line-diff option
ok 14 - validate the --full-line-diff output.
ok 15 - Show the line level log of path0 with --graph
ok 16 - Show the line level log of path1 with --graph
ok 17 - Show the line level log of two files with --graph
ok 18 - Test the line number argument with --graph
ok 19 - Test the --full-line-diff option with --graph option
ok 20 - validate the path0 output.
ok 21 - validate the path1 output.
ok 22 - validate the all path output.
ok 23 - validate graph output
ok 24 - validate --full-line-diff output
# passed all 24 test(s)
1..24
