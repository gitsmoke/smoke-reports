ok 1 - setup binary file with history
ok 2 - file is considered binary by porcelain
ok 3 - file is considered binary by plumbing
ok 4 - setup textconv filters
ok 5 - diff produces text
ok 6 - diff-tree produces binary
ok 7 - log produces text
ok 8 - format-patch produces binary
ok 9 - status -v produces text
ok 10 - diffstat does not run textconv
ok 11 - textconv does not act on symlinks
# passed all 11 test(s)
1..11
