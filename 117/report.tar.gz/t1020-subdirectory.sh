ok 1 - setup
ok 2 - update-index and ls-files
ok 3 - cat-file
ok 4 - diff-files
ok 5 - write-tree
ok 6 - checkout-index
ok 7 - read-tree
ok 8 - no file/rev ambiguity check inside .git
ok 9 - no file/rev ambiguity check inside a bare repo
ok 10 - detection should not be fooled by a symlink
# passed all 10 test(s)
1..10
