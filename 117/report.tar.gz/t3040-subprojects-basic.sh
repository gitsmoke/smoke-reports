ok 1 - Super project creation
ok 2 - create subprojects
ok 3 - check if fsck ignores the subprojects
ok 4 - check if commit in a subproject detected
ok 5 - check if a changed subproject HEAD can be committed
ok 6 - check if diff-index works for subproject elements
ok 7 - check if diff-tree works for subproject elements
ok 8 - check if git diff works for subproject elements
ok 9 - check if clone works
ok 10 - removing and adding subproject
ok 11 - checkout in superproject
# passed all 11 test(s)
1..11
