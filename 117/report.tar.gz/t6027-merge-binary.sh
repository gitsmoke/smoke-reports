ok 1 - setup
ok 2 - resolve
ok 3 - recursive
# passed all 3 test(s)
1..3
