ok 1 - set up basic repo
ok 2 - correct file objects
ok 3 - incorrect revision id
ok 4 - incorrect file in sha1:path
ok 5 - incorrect file in :path and :N:path
ok 6 - invalid @{n} reference
# passed all 6 test(s)
1..6
