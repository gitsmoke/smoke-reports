ok 1 - initialize repo
ok 2 - clone
ok 3 - git svn gc runs
ok 4 - git svn mkdirs recreates empty directories after git svn gc
# passed all 4 test(s)
1..4
