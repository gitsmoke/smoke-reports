ok 1 - setup
ok 2 - apply git diff with -p2
ok 3 - apply with too large -p
ok 4 - apply (-p2) traditional diff with funny filenames
ok 5 - apply with too large -p and fancy filename
# passed all 5 test(s)
1..5
