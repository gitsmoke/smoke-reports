ok 1 - setup
ok 2 - cherry-pick using --ff fast forwards
ok 3 - cherry-pick not using --ff does not fast forwards
ok 4 - merge setup
ok 5 - cherry-pick a non-merge with --ff and -m should fail
ok 6 - cherry pick a merge with --ff but without -m should fail
ok 7 - cherry pick with --ff a merge (1)
ok 8 - cherry pick with --ff a merge (2)
ok 9 - cherry pick a merge relative to nonexistent parent with --ff should fail
# passed all 9 test(s)
1..9
