ok 1 - setup
ok 2 - pulling from real subdir
ok 3 - pulling from symlinked subdir
ok 4 - pushing from symlinked subdir
# passed all 4 test(s)
1..4
