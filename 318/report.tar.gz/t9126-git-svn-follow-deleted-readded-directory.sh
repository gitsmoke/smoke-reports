ok 1 - load repository
ok 2 - fetch repository
# passed all 2 test(s)
1..2
