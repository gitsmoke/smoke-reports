ok 1 - setup
ok 2 - GIT_EXTERNAL_DIFF environment
ok 3 - GIT_EXTERNAL_DIFF environment should apply only to diff
ok 4 - GIT_EXTERNAL_DIFF environment and --no-ext-diff
ok 5 - diff attribute
ok 6 - diff attribute should apply only to diff
ok 7 - diff attribute and --no-ext-diff
ok 8 - diff attribute
ok 9 - diff attribute should apply only to diff
ok 10 - diff attribute and --no-ext-diff
ok 11 - no diff with -diff
ok 12 - force diff with "diff"
ok 13 - GIT_EXTERNAL_DIFF with more than one changed files
ok 14 - GIT_EXTERNAL_DIFF generates pretty paths
ok 15 - external diff with autocrlf = true
ok 16 - diff --cached
# passed all 16 test(s)
1..16
